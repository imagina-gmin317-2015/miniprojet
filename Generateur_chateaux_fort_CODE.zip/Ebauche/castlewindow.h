#ifndef CASTLEWINDOW
#define CASTLEWINDOW

#include "openglwindow.h"
#include "camera.h"

#include <QtGui/QGuiApplication>
#include <QtGui/QMatrix4x4>
#include <QtGui/QOpenGLShaderProgram>
#include <QtGui/QScreen>

#include <QtCore/qmath.h>

#include <QMouseEvent>
#include <QKeyEvent>

#include <QOpenGLTexture>

#include <GL/glu.h>
#include <GL/glut.h>
#include <GL/freeglut.h>
#include <GL/gl.h>




static const char *vertexShaderSource =
    "#version 120\n"
    "attribute highp vec4 posAttr;\n" //Positions des vertex
    "attribute highp vec3 nmAttr;\n"  //Positions des vertex normales
    "attribute lowp vec2 uvAttr;\n"   //Position de la texture
    "attribute highp vec3 tangent;\n" //Vecteur tangent
    "attribute highp vec3 bitangent;\n"//Vecteur bitangent

                                     //A transmettre au fragment shader
    "varying lowp vec2 uv;\n"        //Positions de la texture
    "varying lowp vec4 p;\n"         //Positions du vertex
    "varying lowp vec3 fragPos;\n"   //Positions du fragment
    "varying lowp vec3 nm;\n"        //Positions des vertex normales
    "varying lowp vec3 tangentLightPos;\n" //Les tangents pour la lumière
    "varying lowp vec3 tangentViewPos;\n"  //vue
    "varying lowp vec3 tangentFragPos;\n"  // fragment


    "uniform highp mat4 matrix;\n"    //WorldMatrix * ViewMatrix * ProjectionMatrix
    "uniform lowp vec3 camPos;\n"    //Vecteur de position de la camera
    "uniform lowp vec3 lightPos;\n"  //Position de la lumière
    "uniform highp mat4 model;\n"     //WorldMatrix
    "void main() {\n"
    "   uv = uvAttr;\n"
    "	p = posAttr;\n"
    "	nm = nmAttr;\n"
    "   fragPos = vec3(model * posAttr);\n"

    "   mat3 normalMatrix = transpose(inverse(mat3(model)));\n"
    "   vec3 T = normalize(normalMatrix * tangent);\n"
    "   vec3 B = normalize(normalMatrix * bitangent);\n"
    "   vec3 N = normalize(normalMatrix * nmAttr);\n"

    "   mat3 TBN = transpose(mat3(T, B, N));\n"
    "   tangentLightPos = TBN * lightPos;\n"
    "   tangentViewPos  = TBN * camPos;\n"
    "   tangentFragPos  = TBN * fragPos;\n"

    "	vec4 wvp_pos = matrix * posAttr;\n"
    "   gl_Position = wvp_pos;\n"
    "}\n";

static const char *fragmentShaderSource =
    "#version 120\n"
    "varying lowp vec2 uv;\n"
    "varying lowp vec3 nm;\n"
    "varying lowp vec4 p;\n"
    "varying lowp vec3 fragpos;\n"
    "varying lowp vec3 tangentLightPos;\n"
    "varying lowp vec3 tangentViewPos;\n"
    "varying lowp vec3 tangentFragPos;\n"

    "uniform sampler2D tex;\n"
    "uniform sampler2D nmTex;\n"

    //"uniform float near;\n"
    //"uniform float far;\n "
/*
        "void main()\n"
        "{\n"
            "float depth = ( 2.0 * near * far) / (far + near - (gl_FragCoord.z * 2.0 - 1.0) * (far -near) )/ far;\n" // divide by far for demonstration
            "gl_FragColor = vec4(vec3(depth), 1.0f);\n"
        "}\n";
*/
    "void main() {\n"
   // "   gl_FragDepth = ( 2.0 * near * far) / (far + near - (gl_FragCoord.z * 2.0 - 1.0) * (far -near) )/ far;\n"
        // Obtain normal from normal map in range [0,1]
    "       vec3 normal = texture2D(nmTex, uv).rgb;\n"
        // Transform normal vector to range [-1,1]
    "       normal = normalize(normal * 2.0 - 1.0);\n"// this normal is in tangent space
        // Get diffuse color
    "       vec3 color = texture2D(tex, uv).rgb;\n"
        // Ambient
    "       vec3 ambient = 0.8 * color;\n"
        // Diffuse
    "       vec3 lightDir = normalize(tangentLightPos - tangentFragPos);"
    "       float diff = max(dot(lightDir, normal), 0.0);\n"
    "       vec3 diffuse = diff * color;\n"
        // Specular
    "       vec3 viewDir = normalize(tangentViewPos - tangentFragPos);\n"
    "       vec3 reflectDir = reflect(-lightDir, normal);\n"
    "       vec3 halfwayDir = normalize(lightDir + viewDir);\n"
    "       float spec = pow(max(dot(normal, halfwayDir), 0.0), 32.0);\n"
    "       vec3 specular = vec3(0.2) * spec;\n"
    "       gl_FragColor = vec4(ambient + diffuse + specular, 1.0f);\n"
    "}\n";



#define nbTextures 3
#define textureGround 0
#define nameTextureGround ":/pave.jpg"
#define nameTextureGroundN ":/pave.jpg"
#define textureWall 1
#define nameTextureWall ":/brickwall.jpg"
#define nameTextureWallN ":/brickwall_normal.jpg"
#define textureWood 2
#define nameTextureWood ":/woodB.jpg"
#define nameTextureWoodN ":/woodB_normal.jpg"

//Utilisé pour les randomisations des détails
#define nbDetails 3
#define numeroHourd 3


//Pour la random du type de tour
#define typeTourCylindre 2
//Pour permettre de créer des tours rondes en partant des paramètres des tours carrées
#define coeffMultTour 5


#define PI 3.14159265359


//Pour stocker les attributs d'une élément (mur, tour...)
struct attributesElement{
    QVector3D dimensions;

    int texture = 1;
    //0 pour aléatoire, 1 pour créneau vers l'extérieur,
    //2 pour le pronlongement vers le haut, 3 pour le hourd
    int details = 0;
};

struct attributesElementL{
    QVector2D dimensionsX;
    QVector2D dimensionsY;
    QVector2D dimensionsZ;

    int texture = 1;
    int details = 0;
};


class CastleWindow : public OpenGLWindow
{
public:
    CastleWindow();
    void initElements( GLint,
    QVector2D,
    GLint,
    GLint,
    GLint,
    GLint,
    attributesElementL,
    attributesElementL);

    void initialize() Q_DECL_OVERRIDE;
    void render() Q_DECL_OVERRIDE;

   /* void setMaFenetre(MaFenetre*);
    MaFenetre * getMaFenetre();
*/
    void setSeed(int);
    void setMinNbMurs(int);
    void setMaxNbMurs(int);
    void setRadius(int);
    void setDetails(int);
    void setXMinMurs(int);
    void setXMaxMurs(int);
    void setYMinMurs(int);
    void setYMaxMurs(int);
    void setZMinMurs(int);
    void setZMaxMurs(int);
    void setDetailsMurs(int);
    void setXMinTours(int);
    void setXMaxTours(int);
    void setYMinTours(int);
    void setYMaxTours(int);
    void setZMinTours(int);
    void setZMaxTours(int);
    void setDetailsTours(int);

    //Récupérer les evenements souris/clavier, puis les transmettre à la caméra
    void mouseMoveEvent ( QMouseEvent * event );
    void keyPressEvent(QKeyEvent *event);

    //Pour randomiser les détails
    int randomDetails(int details, int nbDetailsI = nbDetails);

    //Renvoie la matrix avec les modifications des 3 vecteurs (permet de modifier la matrice pour chaque dessin)
    QMatrix4x4 createMatrixWorld(QVector3D translate, QVector3D rotate, QVector3D scale);

    //Initiliase les textures, 0 pour le ground, 1 pour les murs
    void initTextures(int nbTexture);

    //Pos est le centre de la face
    //Texture est la texture à utiliser, 0 pour le sol, 1 pour les murs
    //Etendue permet de répéter la texture plusieurs fois
    void createFace(QVector3D pos, GLfloat lenghtX, GLfloat lenghtY,
                    QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, QVector2D etendue = QVector2D(1,1));



    //On crée une face triangle
    void createFaceTriangle(QVector3D pos, GLfloat lenghtX, GLfloat lenghtY,
                    QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);

    //On crée une face dont on donne les 4 points
    void createFaceParam(QVector3D pos1, QVector3D pos2, QVector3D pos3, QVector3D pos4,
                    QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, QVector2D etendue = QVector2D(1,1));



    void createCube(GLfloat lenght, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);

    //On crée un cube dont on donne les 8 points
    void createCubeParam(QVector3D* pos, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);


    //nbCubes stocke le nombre de cubes à afficher sur chaque dimension
    void createMur(GLfloat dim, QVector3D nbCubes, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, int details = 0);

    //rdCre détermine si on a les créneaux : 1 - Prolongement Extérieur   2 - Prolongement Haut 0 - Random
    //nbCube est le nombre de cubes nécessitant des créneaux
    void createCrenelage(GLfloat lenght, GLfloat nbCubes, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, int details = 0);

    //Le "toit" en bois qui surplombe le mur
    void createHourd(GLfloat lenght, QVector2D nbCubes, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                     QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);

    //Créer une planche sur un cube
    //Dimensions est la taille en x,y,z de la planche, utile pour faire un toit
    void createPlank(QMatrix4x4 matGlobale, QVector3D dimensions = QVector3D(1,0.1,1), QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);

    //Créer une planche avec un trou au centre de dimension hole
    void createPerforedPlank(QMatrix4x4 matGlobale, QVector3D dimensions = QVector3D(1,0.1,1), QVector2D hole = QVector2D(0.5,0.5), QVector3D translate = QVector3D(0,0,0),
                    QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);



    void createTour(GLfloat dim, QVector3D nbCubes, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                        QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, int details = 0);


    void createHautTour(GLfloat lenght, QVector2D nbCubes, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                        QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, int details = 0);

    //Lenght est la longueur entre le centre du cylinder et le milieu de l'arête opposée d'une face
    //nbCubes.x est le nombre de triangle formant la base (4 pour un carré)
    //nbCubes.y est le nombre de faces en hauteur
    void createTourCylinder(GLfloat lenght, QVector2D nbCubes,QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                        QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, int details = 0);

    void createHautTourCylinder(GLfloat lenght, QVector2D nbCubes, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                        QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, int rdCre = 0);

    void createHautTourCylinderHourd(GLfloat lenght, QVector2D nbCubes, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                                     QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);

    //Permet de faire les jointures entre les murs et les tours
    void createJoint(GLfloat lenghtMur, attributesElement attrMur, GLfloat lenghtTour, attributesElement attrTour, GLfloat angle, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                     QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1));


    void generateEnceinte(
            //Attributs des cubes
            GLfloat lenght,
            //Attributs de l'enceinte
            int nbCotesEnceinte,
            //Attributs des murs
            attributesElement attrMur,
            //Type de la tours, comme details
            int typeTours,
            //Attributs des tours
            attributesElement attrTour,
            QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale,
            int texture = 1, int details = 0);

    //Faces stocke les points de chaque face, une face étant donc 4 points consécutifs
    //Répétitions donne pour chaque face, le nombre de fois où la texture doit être répétée
    void createPolygon(GLint nbFaces, QVector3D *faces, QVector2D *repetitions, QMatrix4x4 matGlobale, QVector3D translate = QVector3D(0,0,0),
                       QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1);

    //Permet de faire la jonction entre une liste de points et une liste de faces
    QVector3D* linkgPointsPoly(QVector3D *points);

    //Mur permet de savoir si on crée un mur ou une tour et donc de gérer les détails
    void createMurPolygon(QVector3D dimensions, QMatrix4x4 matGlobale,GLfloat lgCreneau = 0.5f, QVector3D translate = QVector3D(0,0,0),
                          QVector3D rotate = QVector3D(0,0,0), QVector3D scale = QVector3D(1,1,1),int texture = 1, int details = 1, bool mur = true);

    //TaillesReeles permet de connaitre les tailles entières (si on 3.62, on retiendra 3, sert pour les textures
    void createCrenelageExterieurPolygon(QVector3D dimensions, QVector3D taillesReelles, QMatrix4x4 matGlobale,GLfloat lgCreneau = 0.5f, bool mur = true);
    void createCrenelageContinuationPolygon(QVector3D dimensions, QVector3D taillesReelles, QMatrix4x4 matGlobale,GLfloat lgCreneau = 0.5f, bool mur = true);
    void createHourdPolygon(QVector3D dimensions, QVector3D taillesReelles, QMatrix4x4 matGlobale,GLfloat lgCreneau = 0.5f, bool mur = true);



    void generateEnceinteL(
            //Graine du random
            GLint seed,
            //Attributs des cubes
            GLfloat lenght,
            //Attributs de l'enceinte (compris entre le x et le y du vecteur, random donc)
            QVector2D nbCotesEnceinte,
            //Le nombre de cubes séparant le centre d'un des côtés
            GLint radius,
            //Attributs des murs
            attributesElementL attrMur,
            //Type de la tours, comme details
            int typeTours,
            //Attributs des tours
            attributesElementL attrTour,
            QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale,
            int texture = 1, int details = 0);


private:
    //MaFenetre *m_maFenetre;

    GLuint loadShader(GLenum type, const char *source);

    //Les différents paramètres à passer aux shaders
    GLuint m_posAttr;
    GLuint m_uvAttr;
    GLuint m_matrixUniform;
    GLuint m_camPos;
    GLuint m_nmAttr;
    GLuint m_tangent;
    GLuint m_bitangent;

    QOpenGLShaderProgram *m_program;
    int m_frame;

    //Textures
    QOpenGLTexture **textures;

    //Gestion de la camera
    Camera cam;


    //Params de ramdoms
    GLint m_seed;
    QVector2D m_nbCotesL;
    GLint m_radius;
    GLint m_typeTour;
    GLint m_texture;
    GLint m_details;

    attributesElementL m_attrMurL;

    attributesElementL m_attrTourL;

};


#endif // CASTLEWINDOW

