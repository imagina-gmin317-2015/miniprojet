#include "mafenetre.h"


#include <iostream>
#include <string>

MaFenetre::MaFenetre() : QWidget()
{
    setFixedSize(250, 800);


    //Seed
    m_textSeed = new QLabel(this);
    m_textSeed->setText("Seed : ");
    m_textSeed->move(10,20);

    m_lcdSeed = new QLCDNumber(this);
    m_lcdSeed->setSegmentStyle(QLCDNumber::Flat);
    m_lcdSeed->move(50, 20);

    m_sliderSeed = new QSlider(Qt::Horizontal, this);
    m_sliderSeed->setRange(0, 1000);
    m_sliderSeed->setGeometry(10, 50, 150, 20);

    QObject::connect(m_sliderSeed, SIGNAL(valueChanged(int)), m_lcdSeed, SLOT(display(int))) ;
    QObject::connect(m_sliderSeed, SIGNAL(valueChanged(int)), this, SLOT(changerSeed(int)));

    //NbMurs
    GLint xNbMurs = 30;
    GLint yNbMurs = 80;
    m_textNbMurs = new QLabel(this);
    m_textNbMurs->setText("Nombre de murs de l'enceinte");
    m_textNbMurs->move(xNbMurs,yNbMurs);

    m_textMinNbMurs = new QLabel(this);
    m_textMinNbMurs->setText("Min :");
    m_textMinNbMurs->move(xNbMurs-20,yNbMurs+20);

    m_textMaxNbMurs = new QLabel(this);
    m_textMaxNbMurs->setText("Max :");
    m_textMaxNbMurs->move(xNbMurs-20,yNbMurs+45);

    m_maxNbMurs = new QLineEdit(this);
    m_maxNbMurs->setText("8");
    m_maxNbMurs->move(xNbMurs+20,yNbMurs+45);

    m_minNbMurs = new QLineEdit(this);
    m_minNbMurs->setText("8");
    m_minNbMurs->move(xNbMurs+20,yNbMurs+20);

    QObject::connect(m_minNbMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerMinNbMurs(const QString &)));
    QObject::connect(m_maxNbMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerMaxNbMurs(const QString &)));


    //Radius
    GLint xRadius = 30;
    GLint yRadius = 180;

    m_textRadius = new QLabel(this);
    m_textRadius->setText("Radius ");
    m_textRadius->move(xRadius-30,yRadius);

    m_radius = new QLineEdit(this);
    m_radius->setText("10");
    m_radius->move(xRadius+20,yRadius-5);

    QObject::connect(m_radius, SIGNAL(textChanged(const QString &)), this, SLOT(changerRadius(const QString &)));

    //Details
    GLint xDetails = 30;
    GLint yDetails = 220;

    m_textDetails = new QLabel(this);
    m_textDetails->setText("Détails ");
    m_textDetails->move(xDetails-30,yDetails);

    m_details = new QLineEdit(this);
    m_details->setText("3");
    m_details->move(xDetails+20,yDetails-5);

    QObject::connect(m_details, SIGNAL(textChanged(const QString &)), this, SLOT(changerDetails(const QString &)));



    //Les murs
    GLint xMurs = 30;
    GLint yMurs = 260;
    m_textMurs = new QLabel(this);
    m_textMurs->setText("Paramètres des murs");
    m_textMurs->move(xMurs,yMurs-10);

    m_textMursX = new QLabel(this);
    m_textMursX->setText("X : ");
    m_textMursX->move(xMurs-30,yMurs+20);

    m_textMursXMin = new QLabel(this);
    m_textMursXMin->setText("Min ");
    m_textMursXMin->move(xMurs-10,yMurs+20);

    m_textMursXMax = new QLabel(this);
    m_textMursXMax->setText("Max ");
    m_textMursXMax->move(xMurs-10,yMurs+40);

    m_minXMurs = new QLineEdit(this);
    m_minXMurs->setText("2");
    m_minXMurs->move(xMurs+20,yMurs+15);

    m_maxXMurs = new QLineEdit(this);
    m_maxXMurs->setText("6");
    m_maxXMurs->move(xMurs+20,yMurs+35);

    QObject::connect(m_minXMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerXMinMurs(const QString &)));
    QObject::connect(m_maxXMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerXMaxMurs(const QString &)));

    yMurs += 50;

    m_textMursY = new QLabel(this);
    m_textMursY->setText("Y : ");
    m_textMursY->move(xMurs-30,yMurs+20);

    m_textMursYMin = new QLabel(this);
    m_textMursYMin->setText("Min ");
    m_textMursYMin->move(xMurs-10,yMurs+20);

    m_textMursYMax = new QLabel(this);
    m_textMursYMax->setText("Max ");
    m_textMursYMax->move(xMurs-10,yMurs+40);

    m_minYMurs = new QLineEdit(this);
    m_minYMurs->setText("2");
    m_minYMurs->move(xMurs+20,yMurs+15);

    m_maxYMurs = new QLineEdit(this);
    m_maxYMurs->setText("3");
    m_maxYMurs->move(xMurs+20,yMurs+35);

    QObject::connect(m_minYMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerYMinMurs(const QString &)));
    QObject::connect(m_maxYMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerYMaxMurs(const QString &)));

    yMurs += 50;

    m_textMursZ = new QLabel(this);
    m_textMursZ->setText("Z : ");
    m_textMursZ->move(xMurs-30,yMurs+20);

    m_textMursZMin = new QLabel(this);
    m_textMursZMin->setText("Min ");
    m_textMursZMin->move(xMurs-10,yMurs+20);

    m_textMursZMax = new QLabel(this);
    m_textMursZMax->setText("Max ");
    m_textMursZMax->move(xMurs-10,yMurs+40);

    m_minZMurs = new QLineEdit(this);
    m_minZMurs->setText("1");
    m_minZMurs->move(xMurs+20,yMurs+15);

    m_maxZMurs = new QLineEdit(this);
    m_maxZMurs->setText("1");
    m_maxZMurs->move(xMurs+20,yMurs+35);

    QObject::connect(m_minZMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerZMinMurs(const QString &)));
    QObject::connect(m_maxZMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerZMaxMurs(const QString &)));

    yMurs += 70;
    m_textDetailsMurs = new QLabel(this);
    m_textDetailsMurs->setText("Details : ");
    m_textDetailsMurs->move(xMurs-30,yMurs);

    m_detailsMurs = new QLineEdit(this);
    m_detailsMurs->setText("2");
    m_detailsMurs->move(xMurs+20,yMurs-5);

    QObject::connect(m_detailsMurs, SIGNAL(textChanged(const QString &)), this, SLOT(changerDetailsMurs(const QString &)));


    //Les Tours
    GLint xTours = 30;
    GLint yTours = 500;
    m_textTours = new QLabel(this);
    m_textTours->setText("Paramètres des Tours");
    m_textTours->move(xTours,yTours-10);

    m_textToursX = new QLabel(this);
    m_textToursX->setText("X : ");
    m_textToursX->move(xTours-30,yTours+20);

    m_textToursXMin = new QLabel(this);
    m_textToursXMin->setText("Min ");
    m_textToursXMin->move(xTours-10,yTours+20);

    m_textToursXMax = new QLabel(this);
    m_textToursXMax->setText("Max ");
    m_textToursXMax->move(xTours-10,yTours+40);

    m_minXTours = new QLineEdit(this);
    m_minXTours->setText("2");
    m_minXTours->move(xTours+20,yTours+15);

    m_maxXTours = new QLineEdit(this);
    m_maxXTours->setText("6");
    m_maxXTours->move(xTours+20,yTours+35);

    QObject::connect(m_minXTours, SIGNAL(textChanged(const QString &)), this, SLOT(changerXMinTours(const QString &)));
    QObject::connect(m_maxXTours, SIGNAL(textChanged(const QString &)), this, SLOT(changerXMaxTours(const QString &)));

    yTours += 50;

    m_textToursY = new QLabel(this);
    m_textToursY->setText("Y : ");
    m_textToursY->move(xTours-30,yTours+20);

    m_textToursYMin = new QLabel(this);
    m_textToursYMin->setText("Min ");
    m_textToursYMin->move(xTours-10,yTours+20);

    m_textToursYMax = new QLabel(this);
    m_textToursYMax->setText("Max ");
    m_textToursYMax->move(xTours-10,yTours+40);

    m_minYTours = new QLineEdit(this);
    m_minYTours->setText("2");
    m_minYTours->move(xTours+20,yTours+15);

    m_maxYTours = new QLineEdit(this);
    m_maxYTours->setText("3");
    m_maxYTours->move(xTours+20,yTours+35);

    QObject::connect(m_minYTours, SIGNAL(textChanged(const QString &)), this, SLOT(changerYMinTours(const QString &)));
    QObject::connect(m_maxYTours, SIGNAL(textChanged(const QString &)), this, SLOT(changerYMaxTours(const QString &)));

    yTours += 50;

    m_textToursZ = new QLabel(this);
    m_textToursZ->setText("Z : ");
    m_textToursZ->move(xTours-30,yTours+20);

    m_textToursZMin = new QLabel(this);
    m_textToursZMin->setText("Min ");
    m_textToursZMin->move(xTours-10,yTours+20);

    m_textToursZMax = new QLabel(this);
    m_textToursZMax->setText("Max ");
    m_textToursZMax->move(xTours-10,yTours+40);

    m_minZTours = new QLineEdit(this);
    m_minZTours->setText("1");
    m_minZTours->move(xTours+20,yTours+15);

    m_maxZTours = new QLineEdit(this);
    m_maxZTours->setText("1");
    m_maxZTours->move(xTours+20,yTours+35);

    QObject::connect(m_minZTours, SIGNAL(textChanged(const QString &)), this, SLOT(changerZMinTours(const QString &)));
    QObject::connect(m_maxZTours, SIGNAL(textChanged(const QString &)), this, SLOT(changerZMaxTours(const QString &)));

    yTours += 70;
    m_textDetailsTours = new QLabel(this);
    m_textDetailsTours->setText("Details : ");
    m_textDetailsTours->move(xTours-30,yTours);

    m_detailsTours = new QLineEdit(this);
    m_detailsTours->setText("3");
    m_detailsTours->move(xTours+20,yTours-5);

    QObject::connect(m_detailsTours, SIGNAL(textChanged(const QString &)), this, SLOT(changerDetailsTours(const QString &)));


}


void MaFenetre::changerSeed(int i){
    m_castle->setSeed(i);
}

void MaFenetre::changerMinNbMurs(const QString & text){
    int i = text.toInt();
    m_castle->setMinNbMurs(i);
}

void MaFenetre::changerMaxNbMurs(const QString & text){
    int i = text.toInt();
    m_castle->setMaxNbMurs(i);
}

void MaFenetre::changerRadius(const QString & text){
    int i = text.toInt();
    m_castle->setRadius(i);
}

void MaFenetre::changerDetails(const QString & text){
    int i = text.toInt();
    m_castle->setDetails(i);
}

void MaFenetre::changerXMinMurs(const QString & text){
    int i = text.toInt();
    m_castle->setXMinMurs(i);
}

void MaFenetre::changerXMaxMurs(const QString & text){
    int i = text.toInt();
    m_castle->setXMaxMurs(i);
}

void MaFenetre::changerYMinMurs(const QString & text){
    int i = text.toInt();
    m_castle->setYMinMurs(i);
}

void MaFenetre::changerYMaxMurs(const QString & text){
    int i = text.toInt();
    m_castle->setYMaxMurs(i);
}

void MaFenetre::changerZMinMurs(const QString & text){
    int i = text.toInt();
    m_castle->setZMinMurs(i);
}

void MaFenetre::changerZMaxMurs(const QString & text){
    int i = text.toInt();
    m_castle->setZMaxMurs(i);
}

void MaFenetre::changerDetailsMurs(const QString & text){
    int i = text.toInt();
    m_castle->setDetailsMurs(i);
}


void MaFenetre::changerXMinTours(const QString & text){
    int i = text.toInt();
    m_castle->setXMinTours(i);
}

void MaFenetre::changerXMaxTours(const QString & text){
    int i = text.toInt();
    m_castle->setXMaxTours(i);
}

void MaFenetre::changerYMinTours(const QString & text){
    int i = text.toInt();
    m_castle->setYMinTours(i);
}

void MaFenetre::changerYMaxTours(const QString & text){
    int i = text.toInt();
    m_castle->setYMaxTours(i);
}

void MaFenetre::changerZMinTours(const QString & text){
    int i = text.toInt();
    m_castle->setZMinTours(i);
}

void MaFenetre::changerZMaxTours(const QString & text){
    int i = text.toInt();
    m_castle->setZMaxTours(i);
}

void MaFenetre::changerDetailsTours(const QString & text){
    int i = text.toInt();
    m_castle->setDetailsTours(i);
}

void MaFenetre::setCW(CastleWindow * cw){
    m_castle = cw;
}


