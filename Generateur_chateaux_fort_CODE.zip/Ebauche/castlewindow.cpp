#include "castlewindow.h"

CastleWindow::CastleWindow()
    : m_program(0)
    , m_frame(0)
{
}

void CastleWindow::initElements(GLint seed,
QVector2D nbCotesL,
GLint radius,
GLint typeTour,
GLint texture,
GLint details,
attributesElementL attrMurL,
attributesElementL attrTourL
)
{

    m_seed = seed;
    m_nbCotesL = nbCotesL;
    m_radius = radius;
    m_typeTour = typeTour;
    m_texture = texture;
    m_details = details;
    m_attrMurL = attrMurL;
    m_attrTourL = attrTourL;

}

/*void CastleWindow::setMaFenetre(MaFenetre* m){
    m_maFenetre = m;
}

MaFenetre* CastleWindow::getMaFenetre(){
    return m_maFenetre;
}
*/
void CastleWindow::setSeed(int l){
    qDebug()<<"Seed :" <<l<<endl;
    m_seed = l;
}

void CastleWindow::setMinNbMurs(int l){
    if(l > 0 && l <= m_nbCotesL.y()){
        m_nbCotesL.setX(l);
        qDebug()<<"Min nbMurs : "<<l<<endl;
    }
}

void CastleWindow::setMaxNbMurs(int l){
     if(l < 15 && l >= m_nbCotesL.x()){
        m_nbCotesL.setY(l);
        qDebug()<<"Max NbMurs : "<<l<<endl;
     }
}

void CastleWindow::setRadius(int l){
    if(l > 0){
       m_radius = l;
       qDebug()<<"Radius : "<<l<<endl;
    }
}

void CastleWindow::setDetails(int l){
    if(l >= 0 && l <=3){
       m_details = l;
       qDebug()<<"Details : "<<l<<endl;
    }
}

void CastleWindow::setXMinMurs(int l){
    if(l > 0 && l <= m_attrMurL.dimensionsX.y()){
        m_attrMurL.dimensionsX.setX(l);
        qDebug()<<"Min x dims murs : "<<l<<endl;
    }
}

void CastleWindow::setXMaxMurs(int l){
    if(l < 15 && l >= m_attrMurL.dimensionsX.x()){
        m_attrMurL.dimensionsX.setY(l);
        qDebug()<<"Max x dims murs : "<<l<<endl;
    }
}

void CastleWindow::setYMinMurs(int l){
    if(l > 0 && l <= m_attrMurL.dimensionsY.y()){
        m_attrMurL.dimensionsY.setX(l);
        qDebug()<<"Min y dims murs : "<<l<<endl;
    }
}

void CastleWindow::setYMaxMurs(int l){
    if(l < 15 && l >= m_attrMurL.dimensionsY.x()){
        m_attrMurL.dimensionsY.setY(l);
        qDebug()<<"Max y dims murs : "<<l<<endl;
    }
}

void CastleWindow::setZMinMurs(int l){
    if(l > 0 && l <= m_attrMurL.dimensionsZ.y()){
        m_attrMurL.dimensionsZ.setX(l);
        qDebug()<<"Min z dims murs : "<<l<<endl;
    }
}

void CastleWindow::setZMaxMurs(int l){
    if(l < 15 && l >= m_attrMurL.dimensionsZ.x()){
        m_attrMurL.dimensionsZ.setY(l);
        qDebug()<<"Max z dims murs : "<<l<<endl;
    }
}

void CastleWindow::setDetailsMurs(int l){
    if(l >= 0 && l <=3){
       m_attrMurL.details = l;
       qDebug()<<"Details murs : "<<l<<endl;
    }
}

void CastleWindow::setXMinTours(int l){
    if(l > 0 && l <= m_attrTourL.dimensionsX.y()){
        m_attrTourL.dimensionsX.setX(l);
        qDebug()<<"Min x dims Tours : "<<l<<endl;
    }
}

void CastleWindow::setXMaxTours(int l){
    if(l < 15 && l >= m_attrTourL.dimensionsX.x()){
        m_attrTourL.dimensionsX.setY(l);
        qDebug()<<"Max x dims Tours : "<<l<<endl;
    }
}

void CastleWindow::setYMinTours(int l){
    if(l > 0 && l <= m_attrTourL.dimensionsY.y()){
        m_attrTourL.dimensionsY.setX(l);
        qDebug()<<"Min y dims Tours : "<<l<<endl;
    }
}

void CastleWindow::setYMaxTours(int l){
    if(l < 15 && l >= m_attrTourL.dimensionsY.x()){
        m_attrTourL.dimensionsY.setY(l);
        qDebug()<<"Max y dims Tours : "<<l<<endl;
    }
}

void CastleWindow::setZMinTours(int l){
    if(l > 0 && l <= m_attrTourL.dimensionsZ.y()){
        m_attrTourL.dimensionsZ.setX(l);
        qDebug()<<"Min z dims Tours : "<<l<<endl;
    }
}

void CastleWindow::setZMaxTours(int l){
    if(l < 15 && l >= m_attrTourL.dimensionsZ.x()){
        m_attrTourL.dimensionsZ.setY(l);
        qDebug()<<"Max z dims Tours : "<<l<<endl;
    }
}

void CastleWindow::setDetailsTours(int l){
    if(l >= 0 && l <=3){
       m_attrTourL.details = l;
       qDebug()<<"Details Tours : "<<l<<endl;
    }
}

//Charger les shaders
GLuint CastleWindow::loadShader(GLenum type, const char *source)
{
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, 0);
    glCompileShader(shader);
    return shader;
}


void CastleWindow::initialize()
{
    // Enable depth buffer    
    glEnable( GL_DEPTH_TEST );
    glDepthFunc( GL_LESS );
     //glDepthFunc( GL_GREATER );

    // Enable back face culling
    glEnable(GL_CULL_FACE);


    glClearColor(1.0f,1.0f,1.0f,1.0f);

    m_program = new QOpenGLShaderProgram(this);
    m_program->addShaderFromSourceCode(QOpenGLShader::Vertex, vertexShaderSource);
    m_program->addShaderFromSourceCode(QOpenGLShader::Fragment, fragmentShaderSource);
    m_program->link();
    m_posAttr = m_program->attributeLocation("posAttr");
    m_uvAttr = m_program->attributeLocation( "uvAttr" );
    m_matrixUniform = m_program->uniformLocation( "matrix" );
    m_camPos = m_program->uniformLocation( "camPos" );
    m_nmAttr = m_program->attributeLocation( "nmAttr" );
    m_tangent = m_program->attributeLocation( "tangent" );
    m_bitangent = m_program->attributeLocation( "bitangent" );

    //TEXTURES
    textures = (QOpenGLTexture**)malloc(sizeof(QOpenGLTexture*) * nbTextures * 2);

    //Sol
    textures[textureGround*2] = new QOpenGLTexture(QImage( nameTextureGround ));
    textures[textureGround*2 + 1] = new QOpenGLTexture( QImage( nameTextureGroundN ) );
    //Mur
    textures[textureWall*2] = new QOpenGLTexture(QImage( nameTextureWall ));
    textures[textureWall*2 + 1] = new QOpenGLTexture(QImage( nameTextureWallN ));
    //Wood
    textures[textureWood*2] = new QOpenGLTexture(QImage( nameTextureWood ));
    textures[textureWood*2 + 1] = new QOpenGLTexture(QImage( nameTextureWoodN ));


    for(int i = 0; i < nbTextures;  i++){
         // Set nearest filtering mode for texture minification
        textures[i]->setMinificationFilter( QOpenGLTexture::NearestMipMapLinear );
        // Set bilinear filtering mode for texture magnification
        textures[i]->setMagnificationFilter( QOpenGLTexture::Linear );
        // Wrap texture coordinates by repeating
        // f.ex. texture coordinate (1.1, 1.2) is same as (0.1, 0.2)
        textures[i]->setWrapMode( QOpenGLTexture::MirroredRepeat );

        textures[i+1]->setMinificationFilter( QOpenGLTexture::NearestMipMapLinear );
        textures[i+1]->setMagnificationFilter( QOpenGLTexture::Linear );
        textures[i+1]->setWrapMode( QOpenGLTexture::MirroredRepeat );

    }


    // initialisation de la camera
    cam = Camera();
    cam.setY(10);
    cam.setZ(15);

    cam.setRotY(-90);

}

//Transmettre les events et les tailles à la caméra
void CastleWindow::mouseMoveEvent ( QMouseEvent * event ){
    static const qreal retinaScale = devicePixelRatio();
    static float hei = height() * retinaScale;
    static float wid = width() * retinaScale;
    cam.mouseMoveEvent(event, retinaScale, hei, wid);
}

//Transmettre les events à la caméra
void CastleWindow::keyPressEvent(QKeyEvent *event){
    cam.keyPressEvent(event);
}


void CastleWindow::render()
{
    //Petits calculs de la fenêtre (taille...)
    const qreal retinaScale = devicePixelRatio();
    glViewport(0, 0, width() * retinaScale, height() * retinaScale);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


    //-------------------------------
    //Binder les textures avec le programme
    m_program->bind();
    for(int i = 0; i < nbTextures ; i++){
        textures[i*2]->bind(i*2);
        textures[i*2 + 1]->bind(i*2 + 1);
    }

    //-------------------------------


    //Gérer la vue
    // la matrice finale = matWORLD * matVIEW * matPROJ
    // on place donc la caméra; la matVIEW
    // OpenGL -> matrices inversees... donc cacul inverse; matPROJ * matVIEW * matWORLD

    QMatrix4x4 matWorld, matView, matProj;
    matWorld.setToIdentity();
    matView.setToIdentity();
    matProj.setToIdentity();

    matWorld.rotate(0,0,0);
    matWorld.translate(0, 0, 0);
    matWorld.scale(1,1,1);

    //Calcul du vecteur directeur de la camera
    float camRotX_rad = (cam.getCamRotX() / 360.0f) * 6.2831853f;
    float camRotY_rad = (cam.getCamRotY() / 360.0f) * 6.2831853f;
    QVector3D cameraDirection(cam.getCamPosX() + cosf(camRotY_rad), cam.getCamPosY() + sinf(camRotX_rad), cam.getCamPosZ() + sinf(camRotY_rad));

    //Où l'on regarde
    matView.lookAt(QVector3D(cam.getCamPosX(), cam.getCamPosY(), cam.getCamPosZ()), cameraDirection, QVector3D(0, 1, 0));

    //Projection, angle de vue...
    float near = 0.1f;
    float far = 100.0f;
    matProj.perspective(80.0f, 4.0f/3.0f, near, far);

    //-------------------------------


    //Fournir au programme l'ensemble des données utiles
    m_program->setUniformValue( m_matrixUniform, matProj * matView * matWorld );
    m_program->setUniformValue( m_camPos, QVector3D( cam.getCamPosX(), cam.getCamPosY(), cam.getCamPosZ() ) );
    m_program->setUniformValue( "tex", 0 );
    m_program->setUniformValue( "nmTex", 1 );
    m_program->setUniformValue( "lightPos", QVector3D(0.5f,1.0f,0.3f));
    m_program->setUniformValue( "model" ,matWorld);
    //m_program->setUniformValue( "near" ,near);
    //m_program->setUniformValue( "far" ,far);


    createFace(QVector3D(0.0, 0.0, 0.0), 50.0, 50.0, matProj*matView*matWorld,QVector3D(0,0,0),QVector3D(-90,0,0),QVector3D(1,1,1),0,QVector2D(50,50));

    //createCube(1.0, matProj*matView*matWorld,QVector3D(0,0,0),QVector3D(0,0,0),QVector3D(1,1,1),1);

    //createCube(2.0, matProj*matView*matWorld,QVector3D(5,1,0),QVector3D(0,45,0),QVector3D(1,1,1),1);

    //createMur(4.0,QVector3D(3.0,2.0,2.0),matProj*matView*matWorld,QVector3D(1,1,0),QVector3D(0,90,0),QVector3D(1,1,1),1,3);

    //createTour(2.0, QVector3D(2.0,5.0,2.0), matProj*matView*matWorld, QVector3D(5,0,0),QVector3D(0,0,0),QVector3D(1,1,1),1,1);

    //createFaceTriangle(QVector3D(0.0, 0.0, 0.0), 5.0, 5.0, matProj*matView*matWorld,QVector3D(0,5,0),QVector3D(0,0,0),QVector3D(1,1,1),0);

    //createTourCylinder(2.0,QVector2D(10,5),matProj*matView*matWorld, QVector3D(0,0,0),QVector3D(0,0,0), QVector3D(1,1,1),1,0);

    ///Petit probleme en Y pour les tours cylindres
   /* attributesElement attrMur;
    attrMur.dimensions = QVector3D(5,2,1);
    attributesElement attrTour;
    attrTour.dimensions = QVector3D(2,4,2);
    generateEnceinte(2.0,5,attrMur,1,attrTour,matProj*matView*matWorld, QVector3D(0,2,0),QVector3D(0,0,0), QVector3D(1,1,1),1,3);
*/
/*
    GLint seed = 7054585;
    QVector2D nbCotesL = QVector2D(5,8);
    GLint radius = 10;
    GLint typeTour = 1;
    GLint texture = 1;
    GLint details = 3;

    attributesElementL attrMurL;
    attrMurL.dimensionsX.setX(4);
    attrMurL.dimensionsX.setY(6);
    attrMurL.dimensionsY.setX(2);
    attrMurL.dimensionsY.setY(3);
    attrMurL.dimensionsZ.setX(1);
    attrMurL.dimensionsZ.setY(1);
    attrMurL.details = 3;

    attributesElementL attrTourL;
    attrTourL.dimensionsX.setX(2);
    attrTourL.dimensionsX.setY(4);
    attrTourL.dimensionsY.setX(4);
    attrTourL.dimensionsY.setY(6);
    attrTourL.dimensionsZ.setX(2);
    attrTourL.dimensionsZ.setY(4);
    attrTourL.details = 1;
*/
    generateEnceinteL(m_seed,1.5f,m_nbCotesL,m_radius,m_attrMurL,m_typeTour,m_attrTourL,matProj*matView*matWorld,QVector3D(0,0,0),QVector3D(0,0,0),QVector3D(1,1,1),m_texture,m_details);

   /* QVector3D *points = (QVector3D *)malloc(8 * sizeof(QVector3D));
    QVector3D *faces = linkgPointsPoly(points);
    QVector2D *repetitions = (QVector2D*)malloc(6 * sizeof(QVector2D));
    points[0] = QVector3D(1,1,-1);
    points[1] = QVector3D(1,1,1);
    points[2] = QVector3D(-1,1,1);
    points[3] = QVector3D(-1,1,-1);

    points[4] = QVector3D(1,-1,-1);
    points[5] = QVector3D(1,-1,1);
    points[6] = QVector3D(-1,-1,1);
    points[7] = QVector3D(-1,-1,-1);

    faces = linkgPointsPoly(points);


    repetitions[0] = QVector2D(2,1);
    repetitions[1] = QVector2D(4,1);
    repetitions[2] = QVector2D(2,1);
    repetitions[3] = QVector2D(4,1);
    repetitions[4] = QVector2D(4,1);
    repetitions[5] = QVector2D(4,1);

    createPolygon(6,faces,repetitions,matProj*matView*matWorld);*/

   /*QVector3D posTest = QVector3D(5,2,2);
   createMurPolygon(posTest,matProj*matView*matWorld,0.5f,QVector3D(0,0,0),QVector3D(0,0,0),QVector3D(1,1,1),1,2,true);
*/

    //createMurPolygon(QVector3D(4,2,1),matProj*matView*matWorld,0.5f,QVector3D(0,1,0),
       //              QVector3D(0,0,0),QVector3D(1,1,1),1,3,true);


    m_program->release();

    ++m_frame;

}


int CastleWindow::randomDetails(int details, int nbDetailsI){
    int rd = details;
    if(rd == 0){
        //srand (time(NULL));
        srand (0);
        rd = (rand() % nbDetailsI) + 1;
    }
    return rd;
}


void CastleWindow::initTextures(int nbText){
    m_program->setUniformValue( "tex", nbText*2 );
    m_program->setUniformValue( "nmTex", (nbText*2)+1 );
}

QMatrix4x4 CastleWindow::createMatrixWorld(QVector3D translate, QVector3D rotate, QVector3D scale){
    QMatrix4x4 matWorld;
    matWorld.setToIdentity();
    matWorld.scale(scale);
    matWorld.translate(translate);
    matWorld.rotate(rotate.x(),QVector3D(1.0,0.0,0.0));
    matWorld.rotate(rotate.y(),QVector3D(0.0,1.0,0.0));
    matWorld.rotate(rotate.z(),QVector3D(0.0,0.0,1.0));

    return matWorld;
}

void CastleWindow::createFace(QVector3D pos, GLfloat lenghtX, GLfloat lenghtY, QMatrix4x4  matGlobale,QVector3D translate, QVector3D rotate, QVector3D scale,int texture,QVector2D etendue){

    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);
    initTextures(texture);

    m_program->setUniformValue( m_matrixUniform, matGlobale * matWorld );


    //Vertex
    QVector3D pos1(pos.x()-lenghtX/2, pos.y()+lenghtY/2, pos.z());
    QVector3D pos2(pos.x()-lenghtX/2, pos.y()-lenghtY/2, pos.z());
    QVector3D pos3(pos.x()+lenghtX/2, pos.y()-lenghtY/2, pos.z());
    QVector3D pos4(pos.x()+lenghtX/2, pos.y()+lenghtY/2, pos.z());
    //Tex
    QVector2D uv1(0.0, etendue.y());
    QVector2D uv2(0.0, 0.0);
    QVector2D uv3(etendue.x(), 0.0);
    QVector2D uv4(etendue.x(), etendue.y());
    //Vecteur Normal
    QVector3D nm;//(0.0, 0.0, 1.0);
    nm.crossProduct(pos1,pos2);

    // calculate tangent/bitangent vectors of both triangles
    QVector3D tangent1, bitangent1;
    QVector3D tangent2, bitangent2;
    // - triangle 1
    QVector3D edge1 = pos2 - pos1;
    QVector3D edge2 = pos3 - pos1;
    QVector2D deltaUV1 = uv2 - uv1;
    QVector2D deltaUV2 = uv3 - uv1;

    GLfloat f = 1.0f / (deltaUV1.x() * deltaUV2.y() - deltaUV2.x() * deltaUV1.y());

    tangent1.setX(f * (deltaUV2.y() * edge1.x() - deltaUV1.y() * edge2.x()));
    tangent1.setY(f * (deltaUV2.y() * edge1.y() - deltaUV1.y() * edge2.y()));
    tangent1.setZ(f * (deltaUV2.y() * edge1.z() - deltaUV1.y() * edge2.z()));
    tangent1.normalize();

    bitangent1.setX(f * (-deltaUV2.x() * edge1.x() + deltaUV1.x() * edge2.x()));
    bitangent1.setY(f * (-deltaUV2.x() * edge1.y() + deltaUV1.x() * edge2.y()));
    bitangent1.setZ(f * (-deltaUV2.x() * edge1.z() + deltaUV1.x() * edge2.z()));
    bitangent1.normalize();

    // - triangle 2
    edge1 = pos3 - pos1;
    edge2 = pos4 - pos1;
    deltaUV1 = uv3 - uv1;
    deltaUV2 = uv4 - uv1;

    f = 1.0f / (deltaUV1.x() * deltaUV2.y() - deltaUV2.x() * deltaUV1.y());

    tangent2.setX(f * (deltaUV2.y() * edge1.x() - deltaUV1.y() * edge2.x()));
    tangent2.setY(f * (deltaUV2.y() * edge1.y() - deltaUV1.y() * edge2.y()));
    tangent2.setZ(f * (deltaUV2.y() * edge1.z() - deltaUV1.y() * edge2.z()));
    tangent2.normalize();


    bitangent2.setX(f * (-deltaUV2.x() * edge1.x() + deltaUV1.x() * edge2.x()));
    bitangent2.setY(f * (-deltaUV2.x() * edge1.y() + deltaUV1.x() * edge2.y()));
    bitangent2.setZ(f * (-deltaUV2.x() * edge1.z() + deltaUV1.x() * edge2.z()));
    bitangent2.normalize();



     GLfloat vertices[] = {
         pos1.x(), pos1.y(), pos1.z(),
         pos2.x(), pos2.y(), pos2.z(),
         pos3.x(), pos3.y(), pos3.z(),

         pos1.x(), pos1.y(), pos1.z(),
         pos3.x(), pos3.y(), pos3.z(),
         pos4.x(), pos4.y(), pos4.z(),
    };

    GLfloat uv[] = {
        uv1.x(),uv1.y(),
        uv2.x(),uv2.y(),
        uv3.x(),uv3.y(),

        uv1.x(),uv1.y(),
        uv3.x(),uv3.y(),
        uv4.x(),uv4.y(),
    };

    GLfloat tangent[] = {
        tangent1.x(), tangent1.y(), tangent1.z(),

        tangent2.x(), tangent2.y(), tangent2.z(),
    };

    GLfloat bitangent[] = {
        bitangent1.x(), bitangent1.y(), bitangent1.z(),

        bitangent2.x(), bitangent2.y(), bitangent2.z(),
    };

    glEnableVertexAttribArray( 0 );
    glEnableVertexAttribArray( 1 );
    glEnableVertexAttribArray( 2 );
    glEnableVertexAttribArray( 3 );

    glVertexAttribPointer( m_posAttr, 3, GL_FLOAT, GL_FALSE, 0, vertices );
    glVertexAttribPointer( m_uvAttr, 2, GL_FLOAT, GL_FALSE, 0, uv );
    glVertexAttribPointer( m_tangent, 3, GL_FLOAT, GL_FALSE, 0, tangent );
    glVertexAttribPointer( m_bitangent, 3, GL_FLOAT, GL_FALSE, 0, bitangent );

    glDrawArrays( GL_TRIANGLES, 0, 6 );

    glDisableVertexAttribArray( 3 );
    glDisableVertexAttribArray( 2 );
    glDisableVertexAttribArray( 1 );
    glDisableVertexAttribArray( 0 );
}

void CastleWindow::createFaceTriangle(QVector3D pos, GLfloat lenghtX, GLfloat lenghtY, QMatrix4x4  matGlobale,QVector3D translate, QVector3D rotate, QVector3D scale,int texture){

    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);
    initTextures(texture);

    m_program->setUniformValue( m_matrixUniform, matGlobale * matWorld );


    //Vertex
    QVector3D pos1(pos.x(), pos.y()+lenghtY/2, pos.z());
    QVector3D pos2(pos.x()-lenghtX/2, pos.y()-lenghtY/2, pos.z());
    QVector3D pos3(pos.x()+lenghtX/2, pos.y()-lenghtY/2, pos.z());
    //Tex
    QVector2D uv1(0.5, 0.5);
    QVector2D uv2(0.0, 0.0);
    QVector2D uv3(1.0, 0.0);
    //Vecteur Normal
    QVector3D nm;//(0.0, 0.0, 1.0);
    nm.crossProduct(pos1,pos2);

    // calculate tangent/bitangent vectors of both triangles
    QVector3D tangent1, bitangent1;
    // - triangle 1
    QVector3D edge1 = pos2 - pos1;
    QVector3D edge2 = pos3 - pos1;
    QVector2D deltaUV1 = uv2 - uv1;
    QVector2D deltaUV2 = uv3 - uv1;

    GLfloat f = 1.0f / (deltaUV1.x() * deltaUV2.y() - deltaUV2.x() * deltaUV1.y());

    tangent1.setX(f * (deltaUV2.y() * edge1.x() - deltaUV1.y() * edge2.x()));
    tangent1.setY(f * (deltaUV2.y() * edge1.y() - deltaUV1.y() * edge2.y()));
    tangent1.setZ(f * (deltaUV2.y() * edge1.z() - deltaUV1.y() * edge2.z()));
    tangent1.normalize();

    bitangent1.setX(f * (-deltaUV2.x() * edge1.x() + deltaUV1.x() * edge2.x()));
    bitangent1.setY(f * (-deltaUV2.x() * edge1.y() + deltaUV1.x() * edge2.y()));
    bitangent1.setZ(f * (-deltaUV2.x() * edge1.z() + deltaUV1.x() * edge2.z()));
    bitangent1.normalize();



     GLfloat vertices[] = {
         pos1.x(), pos1.y(), pos1.z(),
         pos2.x(), pos2.y(), pos2.z(),
         pos3.x(), pos3.y(), pos3.z()
    };

    GLfloat uv[] = {
        uv1.x(),uv1.y(),
        uv2.x(),uv2.y(),
        uv3.x(),uv3.y()
    };

    GLfloat tangent[] = {
        tangent1.x(), tangent1.y(), tangent1.z()
    };

    GLfloat bitangent[] = {
        bitangent1.x(), bitangent1.y(), bitangent1.z()
    };

    glEnableVertexAttribArray( 0 );
    glEnableVertexAttribArray( 1 );
    glEnableVertexAttribArray( 2 );
    glEnableVertexAttribArray( 3 );

    glVertexAttribPointer( m_posAttr, 3, GL_FLOAT, GL_FALSE, 0, vertices );
    glVertexAttribPointer( m_uvAttr, 2, GL_FLOAT, GL_FALSE, 0, uv );
    glVertexAttribPointer( m_tangent, 3, GL_FLOAT, GL_FALSE, 0, tangent );
    glVertexAttribPointer( m_bitangent, 3, GL_FLOAT, GL_FALSE, 0, bitangent );

    glDrawArrays( GL_TRIANGLES, 0, 3 );

    glDisableVertexAttribArray( 3 );
    glDisableVertexAttribArray( 2 );
    glDisableVertexAttribArray( 1 );
    glDisableVertexAttribArray( 0 );
}

void CastleWindow::createFaceParam(QVector3D pos1, QVector3D pos2, QVector3D pos3, QVector3D pos4, QMatrix4x4  matGlobale,QVector3D translate, QVector3D rotate, QVector3D scale,int texture, QVector2D etendue){

    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);
    initTextures(texture);

    m_program->setUniformValue( m_matrixUniform, matGlobale * matWorld );

    //Tex
    QVector2D uv1(0.0, etendue.y());
    QVector2D uv2(0.0, 0.0);
    QVector2D uv3(etendue.x(), 0.0);
    QVector2D uv4(etendue.x(), etendue.y());
    //Vecteur Normal
    QVector3D nm;//(0.0, 0.0, 1.0);
    nm.crossProduct(pos1,pos2);

    // calculate tangent/bitangent vectors of both triangles
    QVector3D tangent1, bitangent1;
    QVector3D tangent2, bitangent2;
    // - triangle 1
    QVector3D edge1 = pos2 - pos1;
    QVector3D edge2 = pos3 - pos1;
    QVector2D deltaUV1 = uv2 - uv1;
    QVector2D deltaUV2 = uv3 - uv1;

    GLfloat f = 1.0f / (deltaUV1.x() * deltaUV2.y() - deltaUV2.x() * deltaUV1.y());

    tangent1.setX(f * (deltaUV2.y() * edge1.x() - deltaUV1.y() * edge2.x()));
    tangent1.setY(f * (deltaUV2.y() * edge1.y() - deltaUV1.y() * edge2.y()));
    tangent1.setZ(f * (deltaUV2.y() * edge1.z() - deltaUV1.y() * edge2.z()));
    tangent1.normalize();

    bitangent1.setX(f * (-deltaUV2.x() * edge1.x() + deltaUV1.x() * edge2.x()));
    bitangent1.setY(f * (-deltaUV2.x() * edge1.y() + deltaUV1.x() * edge2.y()));
    bitangent1.setZ(f * (-deltaUV2.x() * edge1.z() + deltaUV1.x() * edge2.z()));
    bitangent1.normalize();

    // - triangle 2
    edge1 = pos3 - pos1;
    edge2 = pos4 - pos1;
    deltaUV1 = uv3 - uv1;
    deltaUV2 = uv4 - uv1;

    f = 1.0f / (deltaUV1.x() * deltaUV2.y() - deltaUV2.x() * deltaUV1.y());

    tangent2.setX(f * (deltaUV2.y() * edge1.x() - deltaUV1.y() * edge2.x()));
    tangent2.setY(f * (deltaUV2.y() * edge1.y() - deltaUV1.y() * edge2.y()));
    tangent2.setZ(f * (deltaUV2.y() * edge1.z() - deltaUV1.y() * edge2.z()));
    tangent2.normalize();


    bitangent2.setX(f * (-deltaUV2.x() * edge1.x() + deltaUV1.x() * edge2.x()));
    bitangent2.setY(f * (-deltaUV2.x() * edge1.y() + deltaUV1.x() * edge2.y()));
    bitangent2.setZ(f * (-deltaUV2.x() * edge1.z() + deltaUV1.x() * edge2.z()));
    bitangent2.normalize();



     GLfloat vertices[] = {
         pos1.x(), pos1.y(), pos1.z(),
         pos2.x(), pos2.y(), pos2.z(),
         pos3.x(), pos3.y(), pos3.z(),

         pos1.x(), pos1.y(), pos1.z(),
         pos3.x(), pos3.y(), pos3.z(),
         pos4.x(), pos4.y(), pos4.z(),
    };

    GLfloat uv[] = {
        uv1.x(),uv1.y(),
        uv2.x(),uv2.y(),
        uv3.x(),uv3.y(),

        uv1.x(),uv1.y(),
        uv3.x(),uv3.y(),
        uv4.x(),uv4.y(),
    };

    GLfloat tangent[] = {
        tangent1.x(), tangent1.y(), tangent1.z(),

        tangent2.x(), tangent2.y(), tangent2.z(),
    };

    GLfloat bitangent[] = {
        bitangent1.x(), bitangent1.y(), bitangent1.z(),

        bitangent2.x(), bitangent2.y(), bitangent2.z(),
    };

    glEnableVertexAttribArray( 0 );
    glEnableVertexAttribArray( 1 );
    glEnableVertexAttribArray( 2 );
    glEnableVertexAttribArray( 3 );

    glVertexAttribPointer( m_posAttr, 3, GL_FLOAT, GL_FALSE, 0, vertices );
    glVertexAttribPointer( m_uvAttr, 2, GL_FLOAT, GL_FALSE, 0, uv );
    glVertexAttribPointer( m_tangent, 3, GL_FLOAT, GL_FALSE, 0, tangent );
    glVertexAttribPointer( m_bitangent, 3, GL_FLOAT, GL_FALSE, 0, bitangent );

    glDrawArrays( GL_TRIANGLES, 0, 6 );

    glDisableVertexAttribArray( 3 );
    glDisableVertexAttribArray( 2 );
    glDisableVertexAttribArray( 1 );
    glDisableVertexAttribArray( 0 );
}

void CastleWindow::createCube(GLfloat lenght, QMatrix4x4  matGlobale,QVector3D translate, QVector3D rotate, QVector3D scale,int texture){

    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    //Face Bas
    createFace(QVector3D(0.0, 0.0, 0.0), lenght, lenght, matGlobale * matWorld,QVector3D(0,-lenght/2.0,0),
               QVector3D(90,0,0),QVector3D(1,1,1),texture);

    //Face Haut
    createFace(QVector3D(0.0, 0.0, 0.0), lenght, lenght, matGlobale * matWorld,QVector3D(0,lenght/2.0,0),
               QVector3D(-90,0,0),QVector3D(1,1,1),texture);

   //Face Avant
   createFace(QVector3D(0.0, 0.0, 0.0), lenght, lenght, matGlobale * matWorld,QVector3D(0,0,lenght/2.0),
               QVector3D(0,0,0),QVector3D(1,1,1),texture);

    //Face Arrière
    createFace(QVector3D(0.0, 0.0, 0.0), lenght, lenght, matGlobale * matWorld,QVector3D(0,0,- lenght/2.0),
               QVector3D(0,180,0),QVector3D(1,1,1),texture);

    //Face Droite
    createFace(QVector3D(0.0, 0.0, 0.0), lenght, lenght, matGlobale * matWorld,QVector3D(lenght/2.0,0,0),
               QVector3D(0,90,0),QVector3D(1,1,1),texture);

    //Face Gauche
    createFace(QVector3D(0.0, 0.0, 0.0), lenght, lenght, matGlobale * matWorld,QVector3D(- lenght/2.0,0,0),
               QVector3D(0,0-90,0),QVector3D(1,1,1),texture);
}

//Pos  : 0---1
//       |\  |\
//       | \ | \
//Gauche |Av3--2 Droite
//       4--|5 |
//       \  |  |
//        \ |De|
//         \7--6
void CastleWindow::createCubeParam(QVector3D* pos, QMatrix4x4  matGlobale,QVector3D translate, QVector3D rotate, QVector3D scale,int texture){

    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    GLfloat bas = 0;//-(pos[4] + pos[5] + pos[6] + pos[7]).y()/4;
    GLfloat haut = 0;// (pos[0] + pos[1] + pos[2] + pos[3]).y()/4;
    GLfloat av = 0;//(pos[0] + pos[1] + pos[4] + pos[5]).z()/4;
    GLfloat de = 0;//-(pos[3] + pos[2] + pos[6] + pos[7]).z()/4;
    GLfloat droite = 0;//(pos[1] + pos[2] + pos[6] + pos[5]).x()/4;
    GLfloat gauche = 0;//-(pos[0] + pos[3] + pos[4] + pos[7]).x()/4;

    //Face Bas
    createFaceParam(pos[4], pos[5], pos[6], pos[7],
               matGlobale * matWorld,QVector3D(0,0,bas),
                    QVector3D(0,0,0),QVector3D(1,1,1),texture);

    //Face Haut
    createFaceParam(pos[3], pos[2], pos[1], pos[0],
               matGlobale * matWorld,QVector3D(0,0,haut),
               QVector3D(0,0,0),QVector3D(1,1,1),texture);

   //Face Avant
   createFaceParam(pos[0], pos[1], pos[5], pos[4],
              matGlobale * matWorld,QVector3D(0,0,av),
               QVector3D(0,0,0),QVector3D(1,1,1),texture);

    //Face Arrière
    createFaceParam(pos[7], pos[6], pos[2], pos[3],
                    matGlobale * matWorld, QVector3D(0,0,de),
               QVector3D(0,0,0),QVector3D(1,1,1),texture);

    //Face Droite
    createFaceParam(pos[1], pos[2], pos[6], pos[5],
                    matGlobale * matWorld,QVector3D(droite,0,0),
               QVector3D(0,0,0),QVector3D(1,1,1),texture);

    //Face Gauche
    createFaceParam(pos[4], pos[7], pos[3], pos[0],
                    matGlobale * matWorld,QVector3D(gauche,0,0),
               QVector3D(0,0,0),QVector3D(1,1,1),texture);
}


void CastleWindow::createMur(GLfloat lenght,QVector3D nbCubes, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale ,int texture, int details){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    int rd = randomDetails(details);

    //Génération du mur
    for(int i = -nbCubes.x()/2; i < nbCubes.x()/2  ; i++){
        for(int j = -nbCubes.y()/2; j < nbCubes.y()/2 ;j++){
            for(int k = -nbCubes.z()/2; k < nbCubes.z()/2 ;k++){
                //Pour bien centrer le mur, si il y a un nombre pair de cube il faut décaler
                GLfloat deplX = i * lenght;
                GLfloat deplY = j * lenght;
                GLfloat deplZ = k * lenght;
                if((int)nbCubes.x() % 2 == 0) deplX += lenght/2;
                if((int)nbCubes.y() % 2 == 0) deplY += lenght/2;
                if((int)nbCubes.z() % 2 == 0) deplZ += lenght/2;

                createCube(lenght,matGlobale*matWorld,QVector3D(deplX,deplY,deplZ),QVector3D(0,0,0),QVector3D(1,1,1),texture);

                if((nbCubes.z() == 1 || k == (int)-nbCubes.z() / 2)&& ( nbCubes.y() == 1 || j == (int)nbCubes.y() / 2 - (((int)nbCubes.y()+1)%2 *1))){//Ne le faire qu'une seule fois, sur bord du rempart

                    if(rd != numeroHourd){
                        createCrenelage(lenght,nbCubes.x(),matGlobale*matWorld,QVector3D(deplX,deplY,deplZ),QVector3D(0,0,0),QVector3D(1,1,1),texture,rd);
                    }else{
                        createHourd(lenght,QVector2D(nbCubes.x(),nbCubes.z()),matGlobale*matWorld,QVector3D(deplX,deplY,deplZ),QVector3D(0,0,0),QVector3D(1,1,1),textureWood);
                     }
               }
            }
        }
    }


}

void CastleWindow::createCrenelage(GLfloat lenght,GLfloat nbCubes,QMatrix4x4 matGlobale,QVector3D translate,QVector3D rotate, QVector3D scale,int texture, int details){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);


    int rd = randomDetails(details);

   //qDebug()<<rd<<endl;
    if(rd == 1){
        GLfloat pas = lenght/2.0;
        QVector3D* pos = (QVector3D*)malloc(sizeof(QVector3D)*8);
        pos[0] = QVector3D(-pas,pas*2,-pas*3/2);
        pos[1] = QVector3D(pas,pas*2,-pas*3/2);
        pos[2] = QVector3D(pas,pas*2,-pas);
        pos[3] = QVector3D(-pas,pas*2,-pas);

        pos[4] = QVector3D(-pas,pas,-pas);
        pos[5] = QVector3D(pas,pas,-pas);
        pos[6] = QVector3D(pas,pas,-pas);
        pos[7] = QVector3D(-pas,pas,-pas);

        createCubeParam(pos,matGlobale*matWorld,QVector3D(0,-pas,0),QVector3D(0,0,0),QVector3D(1,1,1),texture);
    }

    bool creneau = false;
    for(int i = -2; i < 2  ; i++){
        GLfloat deplX = i*lenght + lenght*((int)nbCubes%2)/2;
        if((int)nbCubes % 2 == 0) deplX += lenght/2.0;
        GLfloat deplY = 3*lenght + lenght/2;
        GLfloat deplZ = -2*lenght + lenght/2;;

        creneau = !creneau;

        if(rd == 1){
            //On repousse les remparts et on ajoute un petit surplomb
            deplZ -= lenght;
            //createCube(lenght,matGlobale*matWorld,QVector3D(deplX,deplY-2*lenght,deplZ),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
            //createCubeParam(pos,matGlobale*matWorld,QVector3D(deplX,deplY-2*lenght-lenght*3/2,deplZ+lenght*3/2),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);

        }
        //créneaux
        if(creneau){
            createCube(lenght,matGlobale*matWorld,QVector3D(deplX+lenght/2,deplY,deplZ),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
        }
        //rebord
        createCube(lenght,matGlobale*matWorld,QVector3D(deplX,deplY-lenght,deplZ),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
    }
}

void CastleWindow::createHourd(GLfloat lenght,QVector2D nbCubes,QMatrix4x4 matGlobale,QVector3D translate,QVector3D rotate, QVector3D scale,int texture){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    GLfloat deplZB = -lenght;

    createPerforedPlank( matGlobale*matWorld, QVector3D(lenght,lenght/10,lenght), QVector2D(lenght/3,lenght/3), QVector3D(0,lenght,deplZB),QVector3D(90,0,0),QVector3D(1,1,1),texture);
    createPerforedPlank( matGlobale*matWorld, QVector3D(lenght,lenght/10,lenght/2), QVector2D(lenght/3,lenght/6), QVector3D(0,lenght/2 - lenght/20,deplZB+lenght/4), QVector3D(0,0,0),QVector3D(1,1,1),texture);

    //Les soutiens sous le surplomb
    GLfloat pas = lenght/8;
    QVector3D* pos = (QVector3D*)malloc(sizeof(QVector3D)*8);
    pos[0] = QVector3D(-pas,pas*4,-pas);
    pos[1] = QVector3D(pas,pas*4,-pas);
    pos[2] = QVector3D(pas/2,pas,2*pas);
    pos[3] = QVector3D(-pas/2,pas,2*pas);

    pos[4] = QVector3D(-pas,0,-pas);
    pos[5] = QVector3D(pas,0,-pas);
    pos[6] = QVector3D(pas/2,0,2*pas);
    pos[7] = QVector3D(-pas/2,0,2*pas);

    createCubeParam(pos,matGlobale*matWorld,QVector3D(-lenght/3,pas*2  + pas/5,-lenght/2),QVector3D(-90,180,0),QVector3D(1,1,1),texture);
    createCubeParam(pos,matGlobale*matWorld,QVector3D(lenght/3,pas*2 + pas/5,-lenght/2),QVector3D(-90,180,0),QVector3D(1,1,1),texture);


    GLfloat deplYB = lenght*3/2;
    GLfloat angleX = -45;
    //Haut
    for(int i = 0; i < nbCubes.y()+2; i++){
        if(i == 0){
            angleX = -45;
            deplZB += lenght/4;
            deplYB += lenght/4;
        }else if( i == nbCubes.y() + 1){
            angleX = 45;
            deplZB -= lenght/4;
            deplYB += lenght/4;
        }else{
            angleX = 0;
        }

        createPlank( matGlobale*matWorld, QVector3D(lenght,lenght/10,lenght), QVector3D(0,deplYB,deplZB), QVector3D(angleX,0,0),QVector3D(1,1,1),texture);

        if(i == 0 ){
            deplYB += lenght/2;
            deplYB -= lenght/4;
            deplZB -= lenght/4;
        }else if(i == nbCubes.y()){
            deplYB -= lenght/2;
        }
        deplZB += lenght;
    }
    deplZB -= lenght;
    deplZB += lenght/4;

    //Sol
    createPerforedPlank( matGlobale*matWorld, QVector3D(lenght,lenght/10,lenght), QVector2D(lenght/3,lenght/3), QVector3D(0,lenght,deplZB),QVector3D(90,0,0),QVector3D(1,1,1),texture);
    createPerforedPlank( matGlobale*matWorld, QVector3D(lenght,lenght/10,lenght/2), QVector2D(lenght/3,lenght/6), QVector3D(0,lenght/2 - lenght/20,deplZB-lenght/4),QVector3D(0,0,0),QVector3D(1,1,1),texture);

    //Surplomb
    createCubeParam(pos,matGlobale*matWorld,QVector3D(-lenght/3,pas*2  + pas/5,deplZB-lenght/2),QVector3D(90,0,0),QVector3D(1,1,1),texture);
    createCubeParam(pos,matGlobale*matWorld,QVector3D(lenght/3,pas*2 + pas/5,deplZB-lenght/2),QVector3D(90,0,0),QVector3D(1,1,1),texture);

}

void CastleWindow::createPlank(QMatrix4x4 matGlobale, QVector3D dimensions,QVector3D translate,QVector3D rotate, QVector3D scale,int texture){
     QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

     //Face Bas
     createFace(QVector3D(0.0, 0.0, 0.0), dimensions.x(), dimensions.z(), matGlobale * matWorld,QVector3D(0,-dimensions.y()/2.0,0),
                QVector3D(90,0,0),QVector3D(1,1,1),texture);

     //Face Haut
     createFace(QVector3D(0.0, 0.0, 0.0), dimensions.x(), dimensions.z(), matGlobale * matWorld,QVector3D(0,dimensions.y()/2.0,0),
                QVector3D(-90,0,0),QVector3D(1,1,1),texture);

    //Face Avant
    createFace(QVector3D(0.0, 0.0, 0.0), dimensions.x(), dimensions.y(), matGlobale * matWorld,QVector3D(0,0,dimensions.z()/2.0),
                QVector3D(0,0,0),QVector3D(1,1,1),texture);

     //Face Arrière
     createFace(QVector3D(0.0, 0.0, 0.0), dimensions.x(), dimensions.y(), matGlobale * matWorld,QVector3D(0,0,- dimensions.z()/2.0),
                QVector3D(0,180,0),QVector3D(1,1,1),texture);

     //Face Droite
     createFace(QVector3D(0.0, 0.0, 0.0), dimensions.z(), dimensions.y(), matGlobale * matWorld,QVector3D(dimensions.x()/2.0,0,0),
                QVector3D(0,90,0),QVector3D(1,1,1),texture);

     //Face Gauche
     createFace(QVector3D(0.0, 0.0, 0.0), dimensions.z(), dimensions.y(), matGlobale * matWorld,QVector3D(-dimensions.x()/2.0,0,0),
                QVector3D(0,0-90,0),QVector3D(1,1,1),texture);
}

void CastleWindow::createPerforedPlank(QMatrix4x4 matGlobale, QVector3D dimensions, QVector2D hole,QVector3D translate,QVector3D rotate, QVector3D scale,int texture){
     QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

     //On crée 9 planks, dont une vide pour le trou
     //Il faut trouver les positions des 8 autres ainsi que leurs nouvelles dimensions
     /*
      *     1   2   3
      *     4       6
      *     7   8   9
      *
      * */

     GLfloat x147 = -(hole.x()/2.0f + (dimensions.x()/2.0f - hole.x()/2.0f)/2.0f);
     GLfloat x369 = hole.x()/2.0f + (dimensions.x()/2.0f - hole.x()/2.0f)/2.0f;

     GLfloat z123 = -(hole.y()/2.0f + (dimensions.z()/2.0f - hole.y()/2.0f)/2.0f);
     GLfloat z789 = hole.y()/2.0f + (dimensions.z()/2.0f - hole.y()/2.0f)/2.0f;


     GLfloat dimX147369 = dimensions.x()/2 - hole.x()/2.0f;
     GLfloat dimZ123789 = dimensions.z()/2 - hole.y()/2.0f;

     createPlank( matGlobale*matWorld, QVector3D(dimX147369,dimensions.y(),dimZ123789), QVector3D(x147,0,z123),QVector3D(0,0,0),QVector3D(1,1,1),texture);
     createPlank( matGlobale*matWorld, QVector3D(hole.x(),dimensions.y(),dimZ123789), QVector3D(0,0,z123),QVector3D(0,0,0),QVector3D(1,1,1),texture);
     createPlank( matGlobale*matWorld, QVector3D(dimX147369,dimensions.y(),dimZ123789), QVector3D(x369,0,z123),QVector3D(0,0,0),QVector3D(1,1,1),texture);

     createPlank( matGlobale*matWorld, QVector3D(dimX147369,dimensions.y(),hole.y()), QVector3D(x147,0,0),QVector3D(0,0,0),QVector3D(1,1,1),texture);
     createPlank( matGlobale*matWorld, QVector3D(dimX147369,dimensions.y(),hole.y()), QVector3D(x369,0,0),QVector3D(0,0,0),QVector3D(1,1,1),texture);

     createPlank( matGlobale*matWorld, QVector3D(dimX147369,dimensions.y(),dimZ123789), QVector3D(x147,0,z789),QVector3D(0,0,0),QVector3D(1,1,1),texture);
     createPlank( matGlobale*matWorld, QVector3D(hole.x(),dimensions.y(),dimZ123789), QVector3D(0,0,z789),QVector3D(0,0,0),QVector3D(1,1,1),texture);
     createPlank( matGlobale*matWorld, QVector3D(dimX147369,dimensions.y(),dimZ123789), QVector3D(x369,0,z789),QVector3D(0,0,0),QVector3D(1,1,1),texture);


}

void CastleWindow::createTour(GLfloat lenght,QVector3D nbCubes, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale ,int texture, int details){

    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    //Génération de la tour
    for(int i = -nbCubes.x()/2; i < nbCubes.x()/2  ; i++){
        for(int j = -nbCubes.y()/2; j < nbCubes.y()/2 ;j++){
            for(int k = -nbCubes.z()/2; k < nbCubes.z()/2 ;k++){
                //Pour bien centrer le mur, si il y a un nombre pair de cube il faut décaler
                GLfloat deplX = i * lenght;
                GLfloat deplY = j * lenght;
                GLfloat deplZ = k * lenght;
                if((int)nbCubes.x() % 2 == 0) deplX += lenght/2;
                if((int)nbCubes.y() % 2 == 0) deplY += lenght/2;
                if((int)nbCubes.z() % 2 == 0) deplZ += lenght/2;

                createCube(lenght,matGlobale*matWorld,QVector3D(deplX,deplY,deplZ),QVector3D(0,0,0),QVector3D(1,1,1),texture);               
            }
        }
    }

    createHautTour(lenght,QVector2D(nbCubes.x(),nbCubes.z()),matGlobale*matWorld,QVector3D(0,lenght*nbCubes.y()/2 + lenght/2,0),QVector3D(0,0,0),QVector3D(1,1,1),texture,details);

}

void CastleWindow::createHautTour(GLfloat lenght, QVector2D nbCubes, QMatrix4x4 matGlobale, QVector3D translate,QVector3D rotate, QVector3D scale,int texture, int details){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    int rd = randomDetails(details);

    GLfloat deplXH = lenght * nbCubes.x()*4/2 - lenght/2;
    GLfloat deplXB = -lenght * nbCubes.x()*4/2 + lenght/2;
    GLfloat deplY = -lenght*3/2;
    GLfloat deplZH = lenght * nbCubes.y()*4/2 - lenght/2;
    GLfloat deplZB = -lenght * nbCubes.y()*4/2 + lenght/2;
    int departX = 0;
    int finX = 4*nbCubes.x();
    int departZ = 0;
    int finZ = 4*nbCubes.y() - 1;
    if(rd == 1){
        deplXH += lenght;
        deplXB -= lenght;

        deplZH += lenght;
        deplZB -= lenght;

        //departX-=1;
        finX+=2;

        //departZ-=1;
        finZ+=2;
    }

    //Pour le surplomb
    if(rd == 1){
        GLfloat pas = lenght/2.0;
        QVector3D* pos = (QVector3D*)malloc(sizeof(QVector3D)*8);
        pos[0] = QVector3D(-pas,pas*2,-pas*3/2);
        pos[1] = QVector3D(pas,pas*2,-pas*3/2);
        pos[2] = QVector3D(pas,pas*2,-pas);
        pos[3] = QVector3D(-pas,pas*2,-pas);

        pos[4] = QVector3D(-pas,pas,-pas);
        pos[5] = QVector3D(pas,pas,-pas);
        pos[6] = QVector3D(pas,pas,-pas);
        pos[7] = QVector3D(-pas,pas,-pas);

        for(int i = -nbCubes.x()/2; i<nbCubes.x()/2;i++){
            GLfloat retouche = 0.0;
            if(((int)nbCubes.x() % 2) == 0){
                retouche+=pas;
            }
            createCubeParam(pos,matGlobale*matWorld,QVector3D(i*lenght + retouche, - lenght - pas,lenght*nbCubes.y()/2 - pas),QVector3D(0,180,0),QVector3D(1,1,1),texture);
            createCubeParam(pos,matGlobale*matWorld,QVector3D(i*lenght + retouche, - lenght - pas,lenght*-nbCubes.y()/2 + pas),QVector3D(0,0,0),QVector3D(1,1,1),texture);
        }

        for(int i = -nbCubes.y()/2; i<nbCubes.y()/2;i++){
            GLfloat retouche = 0.0;
            if(((int)nbCubes.y() % 2) == 0){
                retouche+=pas;
            }
            createCubeParam(pos,matGlobale*matWorld,QVector3D(lenght*nbCubes.x()/2 - pas, - lenght - pas,i*lenght + retouche),QVector3D(0,-90,0),QVector3D(1,1,1),texture);
            createCubeParam(pos,matGlobale*matWorld,QVector3D(-lenght*nbCubes.x()/2 + pas, - lenght - pas,i*lenght + retouche),QVector3D(0,90,0),QVector3D(1,1,1),texture);
        }
    }


    bool creneau = true;
    for(int i = departX; i < finX ; i++){
        GLfloat deplXHB = deplXH - i * lenght;
        createCube(lenght,matGlobale*matWorld,QVector3D(deplXHB,deplY,deplZH),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
        createCube(lenght,matGlobale*matWorld,QVector3D(deplXHB,deplY,deplZB),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
        /*if(rd == 1){//Surplomb
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXHB,deplY-lenght,deplZH),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXHB,deplY-lenght,deplZB),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
        }*/
        //Créneau
        if(creneau){
            GLfloat deplYB = deplY + lenght;
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXHB-lenght/2,deplYB,deplZH),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXHB-lenght/2,deplYB,deplZB),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);

        }
        creneau = !creneau;
    }
    creneau = true;
    for(int i = departZ; i < finZ ; i++){
        GLfloat deplZHB = deplZH - i * lenght;
        createCube(lenght,matGlobale*matWorld,QVector3D(deplXH,deplY,deplZHB),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
        createCube(lenght,matGlobale*matWorld,QVector3D(deplXB,deplY,deplZHB),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
        /*if(rd == 1){//Surplomb
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXH,deplY-lenght,deplZHB),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXB,deplY-lenght,deplZHB),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
        }*/
        //Créneau
        if(creneau){
            GLfloat deplYB = deplY + lenght;
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXH,deplYB,deplZHB-lenght/2),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);
            createCube(lenght,matGlobale*matWorld,QVector3D(deplXB,deplYB,deplZHB-lenght/2),QVector3D(0,0,0),QVector3D(0.25,0.25,0.25),texture);

        }
        creneau = !creneau;
    }
}


void CastleWindow::createTourCylinder(GLfloat lenght, QVector2D nbCubes,QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale,int texture, int details){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    int rd = randomDetails(details);

    GLfloat rotPas = 360.0 / nbCubes.x();
    GLfloat rot = 0;
    GLfloat lenghtX = 2 * (lenght / tan((90 - ((360.0/nbCubes.x())/2)) * PI/180.0));//on calcule la longeur du segment de la face opposé au centre du cercle via les fonctions trigo de base
    for(int i = 0; i < nbCubes.x() ; i++){
        //Création du haut et du bas
        GLfloat posX = (lenght/2)*cos(rot *PI/180.0);
        GLfloat posY = (lenght/2)*sin(rot *PI/180.0);
        //Faces bas
        createFaceTriangle(QVector3D(0,0,0), lenghtX,lenght, matGlobale*matWorld,QVector3D(posX,-lenght*nbCubes.y()/2,posY),QVector3D(90,0,90 + rot),QVector3D(1,1,1),texture);
        //Faces haut
        createFaceTriangle(QVector3D(0,0,0), lenghtX,lenght, matGlobale*matWorld,QVector3D(posX,lenght*nbCubes.y()/2,posY),QVector3D(-90,0,90 - rot),QVector3D(1,1,1),texture);

        //Création des faces de côtés
        GLfloat posC = -lenght*nbCubes.y()/2 + lenght/2;
        for(int j = 0 ; j < nbCubes.y() ;j++){
            createFace(QVector3D(0,0,0), lenghtX,lenght, matGlobale*matWorld, QVector3D(posX*2,posC,posY*2),QVector3D(0,90-rot,0),QVector3D(1,1,1),texture);
            posC += lenght;
        }

        rot += rotPas;
    }

    if(rd == numeroHourd){
       createHautTourCylinderHourd(lenght, nbCubes, matGlobale*matWorld, QVector3D(0,lenght*nbCubes.y()/2,0),QVector3D(0,0,0),QVector3D(1,1,1),textureWood);
    }else{
        createHautTourCylinder(lenght,nbCubes,matGlobale*matWorld,QVector3D(0,lenght*nbCubes.y()/2,0),QVector3D(0,0,0),QVector3D(1,1,1),texture,rd);
    }
}

void CastleWindow::createHautTourCylinder(GLfloat lenght, QVector2D nbCubes, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale, int texture, int details){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    int rd = randomDetails(details);

    GLfloat pas = 0.25;
    QVector3D* pos = (QVector3D*)malloc(sizeof(QVector3D)*8);
    pos[0] = QVector3D(-pas,pas*2,-pas);
    pos[1] = QVector3D(pas,pas*2,-pas);
    pos[2] = QVector3D(pas/2,pas,pas);
    pos[3] = QVector3D(-pas/2,pas,pas);

    pos[4] = QVector3D(-pas,0,-pas);
    pos[5] = QVector3D(pas,0,-pas);
    pos[6] = QVector3D(pas/2,0,pas);
    pos[7] = QVector3D(-pas/2,0,pas);

    QVector3D* posExt = (QVector3D*)malloc(sizeof(QVector3D)*8);
    posExt[0] = QVector3D(-pas,pas*2,-2*pas);
    posExt[1] = QVector3D(pas,pas*2,-2*pas);
    posExt[2] = QVector3D(pas,pas*2,-pas);
    posExt[3] = QVector3D(-pas,pas*2,-pas);

    posExt[4] = QVector3D(-pas,0,-2*pas);
    posExt[5] = QVector3D(pas,0,-2*pas);
    posExt[6] = QVector3D(pas,0,-pas);
    posExt[7] = QVector3D(-pas,0,-pas);

    QVector3D* posExtBas = (QVector3D*)malloc(sizeof(QVector3D)*8);
    posExtBas[0] = QVector3D(-pas,pas*2,-2*pas);
    posExtBas[1] = QVector3D(pas,pas*2,-2*pas);
    posExtBas[2] = QVector3D(pas,pas*2,-pas);
    posExtBas[3] = QVector3D(-pas,pas*2,-pas);

    posExtBas[4] = QVector3D(-pas,0,-pas);
    posExtBas[5] = QVector3D(pas,0,-pas);
    posExtBas[6] = QVector3D(pas,0,-pas);
    posExtBas[7] = QVector3D(-pas,0,-pas);

    GLfloat rotPas = 360.0 / nbCubes.x();
    GLfloat rot = 0;
    for(int i = 0; i < nbCubes.x() ; i++){
        GLfloat posX = (lenght-pas)*cos(rot *PI/180.0);
        GLfloat posY = (lenght-pas)*sin(rot *PI/180.0);
        createCubeParam(pos,matGlobale*matWorld,QVector3D(posX,0,posY),QVector3D(0,180+90-rot,0));

        if(rd == 1){
            createCubeParam(posExt,matGlobale*matWorld,QVector3D(posX,0,posY),QVector3D(0,180+90-rot,0));
            createCubeParam(posExtBas,matGlobale*matWorld,QVector3D(posX,-pas*2,posY),QVector3D(0,180+90-rot,0));

        }
        rot += rotPas;
    }


    //createCubeParam(pos,matGlobale*matWorld);
}

void CastleWindow::createHautTourCylinderHourd(GLfloat lenght, QVector2D nbCubes, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale,int texture){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    //createCube(4,matGlobale * matWorld,QVector3D(0,0,0),QVector3D(0,0,0),QVector3D(1,1,1));

    GLfloat hauteurToit = lenght/2;
    GLfloat epaisseurToit = lenght/20;

    GLfloat rotPas = 360.0 / nbCubes.x();
    GLfloat rot = 0;

    GLfloat posX = (lenght*1.1)*cos(rot *PI/180.0);
    GLfloat posY = (lenght*1.1)*sin(rot *PI/180.0);

    GLfloat oldPosX = (lenght*1.1)*cos((360-rotPas) *PI/180.0);
    GLfloat oldPosY = (lenght*1.1)*sin((360-rotPas) *PI/180.0);

    for(int i = 0; i < nbCubes.x()+1 ; i++){

        posX = (lenght*1.1)*cos(rot *PI/180.0);
        posY = (lenght*1.1)*sin(rot *PI/180.0);

        QVector3D* pos = (QVector3D*)malloc(sizeof(QVector3D)*8);
        pos[0] = QVector3D(oldPosX,0,oldPosY);
        pos[1] = QVector3D(posX,0,posY);
        pos[2] = QVector3D(0,hauteurToit,0);
        pos[3] = QVector3D(0,hauteurToit,0);

        pos[4] = QVector3D(oldPosX,0-epaisseurToit,oldPosY);
        pos[5] = QVector3D(posX,0-epaisseurToit,posY);
        pos[6] = QVector3D(0,hauteurToit-epaisseurToit,0);
        pos[7] = QVector3D(0,hauteurToit-epaisseurToit,0);

        //Toit
        createCubeParam(pos,matGlobale*matWorld, QVector3D(0,hauteurToit*11/10,0),QVector3D(0,0,0),QVector3D(1,1,1),texture);

        GLfloat murPosX = (lenght)*cos(rot *PI/180.0);
        GLfloat murPosY = (lenght)*sin(rot *PI/180.0);
        createPerforedPlank(matGlobale*matWorld, QVector3D(hauteurToit*4/3,hauteurToit/10,hauteurToit),QVector2D(hauteurToit/3,hauteurToit/3),QVector3D(murPosX,hauteurToit/2,murPosY),QVector3D(90,0,90+rot),QVector3D(1,1,1),texture);



        rot += rotPas;
        oldPosX = posX;
        oldPosY = posY;
    }

}

void CastleWindow::createJoint(GLfloat lenghtMur, attributesElement attrMur, GLfloat lenghtTour, attributesElement attrTour, GLfloat angle, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale){

    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    //Ou AC est le côté du triangle formant la jointure et reliant le mur à la tour
    GLfloat lenghtAC = sin(angle * PI/180) * lenghtMur * attrMur.dimensions.z() / sin((90-angle) * PI/180);//tan(angle) * lenghtMur * attrMur.dimensions.z();

    //qDebug()<<angle<<endl;


    QVector3D* pos = (QVector3D*)malloc(sizeof(QVector3D)*8);
    pos[0] = QVector3D((lenghtMur*attrMur.dimensions.x())/2,-(lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[1] = QVector3D((lenghtMur*attrMur.dimensions.x())/2,-(lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[2] = QVector3D(lenghtAC + (lenghtMur*attrMur.dimensions.x())/2,-(lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);
    pos[3] = QVector3D((lenghtMur*attrMur.dimensions.x())/2,-(lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);

    pos[4] = QVector3D((lenghtMur*attrMur.dimensions.x())/2, (lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[5] = QVector3D((lenghtMur*attrMur.dimensions.x())/2, (lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[6] = QVector3D(lenghtAC + (lenghtMur*attrMur.dimensions.x())/2, (lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);
    pos[7] = QVector3D((lenghtMur*attrMur.dimensions.x())/2, (lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);

    createCubeParam(pos,matGlobale*matWorld, QVector3D(0,0,0),QVector3D(0,0,0),QVector3D(1,1,1));


    pos[0] = QVector3D(-(lenghtMur*attrMur.dimensions.x())/2, (lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[1] = QVector3D(-(lenghtMur*attrMur.dimensions.x())/2, (lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[2] = QVector3D(-(lenghtAC + (lenghtMur*attrMur.dimensions.x())/2), (lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);
    pos[3] = QVector3D(-(lenghtMur*attrMur.dimensions.x())/2, (lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);

    pos[4] = QVector3D(-(lenghtMur*attrMur.dimensions.x())/2,-(lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[5] = QVector3D(-(lenghtMur*attrMur.dimensions.x())/2,-(lenghtMur*attrMur.dimensions.y())/2, (lenghtMur*attrMur.dimensions.z())/2);
    pos[6] = QVector3D(-(lenghtAC + (lenghtMur*attrMur.dimensions.x())/2),-(lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);
    pos[7] = QVector3D(-(lenghtMur*attrMur.dimensions.x())/2,-(lenghtMur*attrMur.dimensions.y())/2, -(lenghtMur*attrMur.dimensions.z())/2);

    createCubeParam(pos,matGlobale*matWorld, QVector3D(0,0,0),QVector3D(0,0,0),QVector3D(1,1,1));

}


void CastleWindow::generateEnceinte(GLfloat lenght, int nbCotesEnceinte, attributesElement attrMur, int typeTour,attributesElement attrTour, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale, int texture, int details){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    int rd = randomDetails(details);
    int tT = randomDetails(typeTour,2);
    if(attrMur.details == 0) attrMur.details = rd;
    if(attrTour.details == 0) attrTour.details = rd;


    GLfloat rotPas = 360.0 / nbCotesEnceinte;
    GLfloat rot = 0;

    //Création des murs
    GLfloat radius = ((lenght * attrMur.dimensions.x())/2.0) * (sin((90.0 - (rotPas/2.0))*PI/180)  / sinf((rotPas/2.0) * PI/180));
    radius += lenght * attrMur.dimensions.z() / 2.0; //Pour la moitié de la largeur du mur
    //Pour rajouter les tours
    GLfloat ajTour = (lenght * attrTour.dimensions.x()) * sin(((180 - rotPas) / 2.0) * PI/180);
    if(rotPas != 90){
        ajTour /= sin(rotPas * PI/180);
    }
    radius += ajTour;

    //qDebug()<<radius<<endl;
    for(int i = 0; i < nbCotesEnceinte ; i++){
        //Création du point central du mur
        GLfloat posX = radius*cos(rot *PI/180.0);
        GLfloat posZ = radius*sin(rot *PI/180.0);
        QVector3D pos = QVector3D(posX,0,posZ);
        createMur(lenght,attrMur.dimensions,matGlobale*matWorld,pos,QVector3D(0,270-rot,0),QVector3D(1,1,1),attrMur.texture,attrMur.details);
        createJoint(lenght,attrMur,lenght, attrTour, rotPas/2.0, matGlobale*matWorld,pos,QVector3D(0,270-rot,0));
        rot += rotPas;
    }

    rot = rotPas/2.0;
    //Création des tours
    for(int i = 0; i < nbCotesEnceinte ; i++){
        //Création du point central de la tour
        GLfloat posX = radius*cos(rot *PI/180.0);
        GLfloat posZ = radius*sin(rot *PI/180.0);
        GLfloat posY = attrTour.dimensions.y() - attrMur.dimensions.y();

        QVector3D pos = QVector3D(posX,posY,posZ);
        if(tT == typeTourCylindre){
            createTourCylinder(lenght, QVector2D(attrTour.dimensions.x()*coeffMultTour,attrTour.dimensions.y()),matGlobale*matWorld,pos,QVector3D(0,270-rot,0),QVector3D(1,1,1),attrTour.texture,attrTour.details);
        }else{
            createTour(lenght,attrTour.dimensions,matGlobale*matWorld,pos,QVector3D(0,270-rot,0),QVector3D(1,1,1),attrTour.texture,attrTour.details);
        }

        rot += rotPas;
    }


}


void CastleWindow::createPolygon(GLint nbFaces, QVector3D *faces, QVector2D *repetitions, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale,int texture){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    for(GLint i = 0 ; i < nbFaces; i++){
        createFaceParam(faces[i*4],faces[i*4 + 1],faces[i*4 + 2],faces[i*4 + 3],matGlobale*matWorld,QVector3D(0,0,0),QVector3D(0,0,0),QVector3D(1,1,1),texture, repetitions[i]);
    }
}

//Pos  : 0---1
//       |\  |\
//       | \ | \
//Gauche |Av3--2 Droite
//       4--|5 |
//       \  |  |
//        \ |De|
//         \7--6

// 0 et 1 en + x et y
// 0 et 3 en  -z
QVector3D* CastleWindow::linkgPointsPoly(QVector3D *points){
    QVector3D *faces = (QVector3D*)malloc(6 * 4 * sizeof(QVector3D));

    //Haut
    faces[0] = points[3];
    faces[3] = points[0];
    faces[2] = points[1];
    faces[1] = points[2];

    //Avant
    faces[7] = points[0];
    faces[6] = points[4];
    faces[5] = points[5];
    faces[4] = points[1];

    //Dessous
    faces[11] = points[7];
    faces[10] = points[6];
    faces[9] = points[5];
    faces[8] = points[4];

    //Arriere
    faces[15] = points[7];
    faces[14] = points[3];
    faces[13] = points[2];
    faces[12] = points[6];

    //Gauche
    faces[16] = points[0];
    faces[19] = points[3];
    faces[18] = points[7];
    faces[17] = points[4];

    //Droite
    faces[23] = points[1];
    faces[22] = points[5];
    faces[21] = points[6];
    faces[20] = points[2];


    return faces;
}

void CastleWindow::createMurPolygon(QVector3D dimensions, QMatrix4x4 matGlobale, GLfloat lgCreneau, QVector3D translate, QVector3D rotate, QVector3D scale,int texture, int details, bool mur){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    int rd = randomDetails(details);

    GLfloat x = dimensions.x() / 2.0f;
    GLfloat y = dimensions.y() / 2.0f;
    GLfloat z = dimensions.z() / 2.0f;


       QVector3D *points = (QVector3D *)malloc(8 * sizeof(QVector3D));
       points[0] = QVector3D(x,y,-z);
       points[1] = QVector3D(x,y,z);
       points[2] = QVector3D(-x,y,z);
       points[3] = QVector3D(-x,y,-z);

       points[4] = QVector3D(x,-y,-z);
       points[5] = QVector3D(x,-y,z);
       points[6] = QVector3D(-x,-y,z);
       points[7] = QVector3D(-x,-y,-z);


       QVector3D *faces = linkgPointsPoly(points);

       GLint xR = dimensions.x();
       GLint yR = dimensions.y();
       GLint zR = dimensions.z();

       QVector2D *repetitions = (QVector2D*)malloc(6 * sizeof(QVector2D));
       repetitions[0] = QVector2D(xR,zR);
       repetitions[1] = QVector2D(zR,yR);
       repetitions[2] = QVector2D(xR,zR);
       repetitions[3] = QVector2D(zR,yR);
       repetitions[4] = QVector2D(xR,yR);
       repetitions[5] = QVector2D(xR,yR);

       createPolygon((GLint)6,faces,repetitions, matGlobale*matWorld);

       switch(rd){

       case 1:
           createCrenelageExterieurPolygon(QVector3D(x,y,z),QVector3D(xR,yR,zR),matGlobale*matWorld,lgCreneau,mur);
           break;

       case 2:
           createCrenelageContinuationPolygon(QVector3D(x,y,z),QVector3D(xR,yR,zR),matGlobale*matWorld,lgCreneau,mur);
           break;

       case 3 :
           createHourdPolygon(QVector3D(x,y,z),QVector3D(xR,yR,zR),matGlobale*matWorld,lgCreneau,mur);
           break;
       }
}

//1
void CastleWindow::createCrenelageExterieurPolygon(QVector3D dimensions, QVector3D taillesReelles, QMatrix4x4 matGlobale, GLfloat lgCreneau, bool mur){
    GLfloat x = dimensions.x();
    GLfloat y = dimensions.y();
    GLfloat z = dimensions.z();

    GLint xR = taillesReelles.x();
    GLint yR = taillesReelles.y();
    GLint zR = taillesReelles.z();

    GLfloat decalageX = lgCreneau;
    GLfloat decalageZ = lgCreneau;

    QVector3D *points = (QVector3D *)malloc(8 * sizeof(QVector3D));
    QVector3D *faces = linkgPointsPoly(points);
    QVector2D *repetitions = (QVector2D*)malloc(6 * sizeof(QVector2D));

    //Le surplomb
    points[0] = QVector3D(x,y,z);
    points[1] = QVector3D(x,y,z+lgCreneau);
    points[2] = QVector3D(-x,y,z+lgCreneau);
    points[3] = QVector3D(-x,y,z);

    points[4] = QVector3D(x,y-lgCreneau,z);
    points[5] = QVector3D(x,y-lgCreneau,z);
    points[6] = QVector3D(-x,y-lgCreneau,z);
    points[7] = QVector3D(-x,y-lgCreneau,z);

    faces = linkgPointsPoly(points);

    repetitions[0] = QVector2D(xR,lgCreneau);
    repetitions[1] = QVector2D(lgCreneau,lgCreneau);
    repetitions[2] = QVector2D(xR,lgCreneau);
    repetitions[3] = QVector2D(lgCreneau,lgCreneau);
    repetitions[4] = QVector2D(xR,lgCreneau);
    repetitions[5] = QVector2D(xR,lgCreneau);

    createPolygon(6,faces,repetitions,matGlobale);
    if(!mur){//on fait le surplomb tout autour
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,0),QVector3D(0,180,0));

        points[0] = QVector3D(x+lgCreneau,y,-z);
        points[1] = QVector3D(x+lgCreneau,y,z);
        points[2] = QVector3D(x,y,z);
        points[3] = QVector3D(x,y,-z);

        points[4] = QVector3D(x,y-lgCreneau,-z);
        points[5] = QVector3D(x,y-lgCreneau,z);
        points[6] = QVector3D(x,y-lgCreneau,z);
        points[7] = QVector3D(x,y-lgCreneau,-z);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(lgCreneau,zR);
        repetitions[1] = QVector2D(zR,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,zR);
        repetitions[3] = QVector2D(zR,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        createPolygon(6,faces,repetitions,matGlobale);
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,0),QVector3D(0,180,0));

        //Les petits coins haut autours de la tour
        points[0] = QVector3D(x+lgCreneau,y+lgCreneau,z);
        points[1] = QVector3D(x+lgCreneau,y+lgCreneau,z);
        points[2] = QVector3D(x,y+lgCreneau,z+lgCreneau);
        points[3] = QVector3D(x,y+lgCreneau,z);

        points[4] = QVector3D(x+lgCreneau,y,z);
        points[5] = QVector3D(x+lgCreneau,y,z);
        points[6] = QVector3D(x,y,z+lgCreneau);
        points[7] = QVector3D(x,y,z);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(lgCreneau,lgCreneau);
        repetitions[1] = QVector2D(zR,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,lgCreneau);
        repetitions[3] = QVector2D(zR,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        createPolygon(6,faces,repetitions,matGlobale);
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,0),QVector3D(0,180,0));


        points[0] = QVector3D(x+lgCreneau,y+lgCreneau,-z);
        points[1] = QVector3D(x+lgCreneau,y+lgCreneau,-z);
        points[2] = QVector3D(x,y+lgCreneau,-z);
        points[3] = QVector3D(x,y+lgCreneau,-z-lgCreneau);

        points[4] = QVector3D(x+lgCreneau,y,-z);
        points[5] = QVector3D(x+lgCreneau,y,-z);
        points[6] = QVector3D(x,y,-z);
        points[7] = QVector3D(x,y,-z-lgCreneau);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(lgCreneau,lgCreneau);
        repetitions[1] = QVector2D(zR,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,lgCreneau);
        repetitions[3] = QVector2D(zR,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        createPolygon(6,faces,repetitions,matGlobale);
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,0),QVector3D(0,180,0));


        //Les petits coins bas autours de la tour
        points[0] = QVector3D(x+lgCreneau,y,z);
        points[1] = QVector3D(x+lgCreneau,y,z);
        points[2] = QVector3D(x,y,z+lgCreneau);
        points[3] = QVector3D(x,y,z);

        points[4] = QVector3D(x,y-lgCreneau,z);
        points[5] = QVector3D(x,y-lgCreneau,z);
        points[6] = QVector3D(x,y-lgCreneau,z);
        points[7] = QVector3D(x,y-lgCreneau,z);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(lgCreneau,lgCreneau);
        repetitions[1] = QVector2D(zR,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,lgCreneau);
        repetitions[3] = QVector2D(zR,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        createPolygon(6,faces,repetitions,matGlobale);
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,0),QVector3D(0,180,0));


        points[0] = QVector3D(x+lgCreneau,y,-z);
        points[1] = QVector3D(x+lgCreneau,y,-z);
        points[2] = QVector3D(x,y,-z);
        points[3] = QVector3D(x,y,-z-lgCreneau);

        points[4] = QVector3D(x,y-lgCreneau,-z);
        points[5] = QVector3D(x,y-lgCreneau,-z);
        points[6] = QVector3D(x,y-lgCreneau,-z);
        points[7] = QVector3D(x,y-lgCreneau,-z);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(lgCreneau,lgCreneau);
        repetitions[1] = QVector2D(zR,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,lgCreneau);
        repetitions[3] = QVector2D(zR,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        createPolygon(6,faces,repetitions,matGlobale);
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,0),QVector3D(0,180,0));
    }

    //Le créneau bas
    points[0] = QVector3D(x,y+lgCreneau,z-lgCreneau);
    points[1] = QVector3D(x,y+lgCreneau,z);
    points[2] = QVector3D(-x,y+lgCreneau,z);
    points[3] = QVector3D(-x,y+lgCreneau,z-lgCreneau);

    points[4] = QVector3D(x,y,z-lgCreneau);
    points[5] = QVector3D(x,y,z);
    points[6] = QVector3D(-x,y,z);
    points[7] = QVector3D(-x,y,z-lgCreneau);

    faces = linkgPointsPoly(points);

    repetitions[0] = QVector2D(xR,lgCreneau);
    repetitions[1] = QVector2D(lgCreneau,lgCreneau);
    repetitions[2] = QVector2D(xR,lgCreneau);
    repetitions[3] = QVector2D(lgCreneau,lgCreneau);
    repetitions[4] = QVector2D(xR,lgCreneau);
    repetitions[5] = QVector2D(xR,lgCreneau);

    createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,decalageZ));
    if(!mur){
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,-decalageZ),QVector3D(0,180,0));
        GLfloat retraitEnZ = 0.0f;

        points[0] = QVector3D(x,y+lgCreneau,-z + retraitEnZ);
        points[1] = QVector3D(x,y+lgCreneau,z - retraitEnZ);
        points[2] = QVector3D(x-lgCreneau,y+lgCreneau,z - retraitEnZ);
        points[3] = QVector3D(x-lgCreneau,y+lgCreneau,-z + retraitEnZ);

        points[4] = QVector3D(x,y,-z + retraitEnZ);
        points[5] = QVector3D(x,y,z - retraitEnZ);
        points[6] = QVector3D(x-lgCreneau,y,z - retraitEnZ);
        points[7] = QVector3D(x-lgCreneau,y,-z + retraitEnZ);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(lgCreneau,zR);
        repetitions[1] = QVector2D(zR,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,zR);
        repetitions[3] = QVector2D(zR,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        createPolygon(6,faces,repetitions,matGlobale,QVector3D(decalageX,0,0));
        createPolygon(6,faces,repetitions,matGlobale,QVector3D(-decalageX,0,0),QVector3D(0,180,0));
    }

    //Le crenelon que l'on va déplacer sur le crenelage précédent
    points[0] = QVector3D(-x+lgCreneau,y+2*lgCreneau,z-lgCreneau);
    points[1] = QVector3D(-x+lgCreneau,y+2*lgCreneau,z);
    points[2] = QVector3D(-x,y+2*lgCreneau,z);
    points[3] = QVector3D(-x,y+2*lgCreneau,z-lgCreneau);

    points[4] = QVector3D(-x+lgCreneau,y+lgCreneau,z-lgCreneau);
    points[5] = QVector3D(-x+lgCreneau,y+lgCreneau,z);
    points[6] = QVector3D(-x,y+lgCreneau,z);
    points[7] = QVector3D(-x,y+lgCreneau,z-lgCreneau);

    faces = linkgPointsPoly(points);


    repetitions[0] = QVector2D(lgCreneau,lgCreneau);
    repetitions[1] = QVector2D(lgCreneau,lgCreneau);
    repetitions[2] = QVector2D(lgCreneau,lgCreneau);
    repetitions[3] = QVector2D(lgCreneau,lgCreneau);
    repetitions[4] = QVector2D(lgCreneau,lgCreneau);
    repetitions[5] = QVector2D(lgCreneau,lgCreneau);


    GLfloat decCre = 0.0f;
    for(GLfloat it = -x + lgCreneau/2.0f + decCre; it < x - lgCreneau/2.0f - decCre; it += lgCreneau*2){

        createPolygon(6,faces,repetitions,matGlobale,QVector3D(it+x,0,decalageZ));
        if(!mur){
            createPolygon(6,faces,repetitions,matGlobale,QVector3D(it+x,0,- 2.0f*z));
        }
    }
    if(!mur){
        points[0] = QVector3D(x,y+2*lgCreneau,-z);
        points[1] = QVector3D(x,y+2*lgCreneau,-z+lgCreneau);
        points[2] = QVector3D(x-lgCreneau,y+2*lgCreneau,-z+lgCreneau);
        points[3] = QVector3D(x-lgCreneau,y+2*lgCreneau,-z);

        points[4] = QVector3D(x,y+lgCreneau,-z);
        points[5] = QVector3D(x,y+lgCreneau,-z+lgCreneau);
        points[6] = QVector3D(x-lgCreneau,y+lgCreneau,-z+lgCreneau);
        points[7] = QVector3D(x-lgCreneau,y+lgCreneau,-z);

        faces = linkgPointsPoly(points);

        decCre = 0.0f;
        if(zR % 2 == 0){
            decCre -= lgCreneau;
        }
        for(GLfloat it = -z + lgCreneau*3/2 + decCre; it < z - lgCreneau*3/2 - decCre; it += lgCreneau*2){
            createPolygon(6,faces,repetitions,matGlobale,QVector3D(decalageX,0,z+it));
            createPolygon(6,faces,repetitions,matGlobale,QVector3D(-2.0f*x,0,z+it));
        }
    }


}

//2
void CastleWindow::createCrenelageContinuationPolygon(QVector3D dimensions, QVector3D taillesReelles, QMatrix4x4 matGlobale, GLfloat lgCreneau, bool mur){

    GLfloat x = dimensions.x();
    GLfloat y = dimensions.y();
    GLfloat z = dimensions.z();

    GLint xR = taillesReelles.x();
    GLint yR = taillesReelles.y();
    GLint zR = taillesReelles.z();

    QVector3D *points = (QVector3D *)malloc(8 * sizeof(QVector3D));
    QVector3D *faces = linkgPointsPoly(points);
    QVector2D *repetitions = (QVector2D*)malloc(6 * sizeof(QVector2D));



    GLfloat decalageX = 0.0f;
    GLfloat decalageZ = 0.0f;

    //Le créneau bas
    points[0] = QVector3D(x,y+lgCreneau,z-lgCreneau);
    points[1] = QVector3D(x,y+lgCreneau,z);
    points[2] = QVector3D(-x,y+lgCreneau,z);
    points[3] = QVector3D(-x,y+lgCreneau,z-lgCreneau);

    points[4] = QVector3D(x,y,z-lgCreneau);
    points[5] = QVector3D(x,y,z);
    points[6] = QVector3D(-x,y,z);
    points[7] = QVector3D(-x,y,z-lgCreneau);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(xR,lgCreneau);
        repetitions[1] = QVector2D(lgCreneau,lgCreneau);
        repetitions[2] = QVector2D(xR,lgCreneau);
        repetitions[3] = QVector2D(lgCreneau,lgCreneau);
        repetitions[4] = QVector2D(xR,lgCreneau);
        repetitions[5] = QVector2D(xR,lgCreneau);

        createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,decalageZ));
        if(!mur){
            createPolygon(6,faces,repetitions,matGlobale,QVector3D(0,0,-decalageZ),QVector3D(0,180,0));
            GLfloat retraitEnZ = lgCreneau;

            points[0] = QVector3D(x,y+lgCreneau,-z + retraitEnZ);
            points[1] = QVector3D(x,y+lgCreneau,z - retraitEnZ);
            points[2] = QVector3D(x-lgCreneau,y+lgCreneau,z - retraitEnZ);
            points[3] = QVector3D(x-lgCreneau,y+lgCreneau,-z + retraitEnZ);

            points[4] = QVector3D(x,y,-z + retraitEnZ);
            points[5] = QVector3D(x,y,z - retraitEnZ);
            points[6] = QVector3D(x-lgCreneau,y,z - retraitEnZ);
            points[7] = QVector3D(x-lgCreneau,y,-z + retraitEnZ);

            faces = linkgPointsPoly(points);

            repetitions[0] = QVector2D(lgCreneau,zR);
            repetitions[1] = QVector2D(zR,lgCreneau);
            repetitions[2] = QVector2D(lgCreneau,zR);
            repetitions[3] = QVector2D(zR,lgCreneau);
            repetitions[4] = QVector2D(lgCreneau,lgCreneau);
            repetitions[5] = QVector2D(lgCreneau,lgCreneau);

            createPolygon(6,faces,repetitions,matGlobale,QVector3D(decalageX,0,0));
            createPolygon(6,faces,repetitions,matGlobale,QVector3D(-decalageX,0,0),QVector3D(0,180,0));
        }

        //Le crenelon que l'on va déplacer sur le crenelage précédent
        points[0] = QVector3D(-x+lgCreneau,y+2*lgCreneau,z-lgCreneau);
        points[1] = QVector3D(-x+lgCreneau,y+2*lgCreneau,z);
        points[2] = QVector3D(-x,y+2*lgCreneau,z);
        points[3] = QVector3D(-x,y+2*lgCreneau,z-lgCreneau);

        points[4] = QVector3D(-x+lgCreneau,y+lgCreneau,z-lgCreneau);
        points[5] = QVector3D(-x+lgCreneau,y+lgCreneau,z);
        points[6] = QVector3D(-x,y+lgCreneau,z);
        points[7] = QVector3D(-x,y+lgCreneau,z-lgCreneau);

        faces = linkgPointsPoly(points);


        repetitions[0] = QVector2D(lgCreneau,lgCreneau);
        repetitions[1] = QVector2D(lgCreneau,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,lgCreneau);
        repetitions[3] = QVector2D(lgCreneau,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        for(GLfloat it = -x + lgCreneau/2.0f ; it < x - lgCreneau/2.0f; it += lgCreneau*2){

            createPolygon(6,faces,repetitions,matGlobale,QVector3D(it+x,0,decalageZ));
            if(!mur){
                createPolygon(6,faces,repetitions,matGlobale,QVector3D(it+x,0,-2*z + lgCreneau));
            }
        }
        if(!mur){
            points[0] = QVector3D(x,y+2*lgCreneau,-z);
            points[1] = QVector3D(x,y+2*lgCreneau,-z+lgCreneau);
            points[2] = QVector3D(x-lgCreneau,y+2*lgCreneau,-z+lgCreneau);
            points[3] = QVector3D(x-lgCreneau,y+2*lgCreneau,-z);

            points[4] = QVector3D(x,y+lgCreneau,-z);
            points[5] = QVector3D(x,y+lgCreneau,-z+lgCreneau);
            points[6] = QVector3D(x-lgCreneau,y+lgCreneau,-z+lgCreneau);
            points[7] = QVector3D(x-lgCreneau,y+lgCreneau,-z);

            faces = linkgPointsPoly(points);
            for(GLfloat it = -z + lgCreneau*3/2 ; it < z - lgCreneau*3/2; it += lgCreneau*2){
                createPolygon(6,faces,repetitions,matGlobale,QVector3D(decalageX,0,z+it));
                createPolygon(6,faces,repetitions,matGlobale,QVector3D(-2*x + lgCreneau,0,z+it));
            }
        }
}

//3
void CastleWindow::createHourdPolygon(QVector3D dimensions, QVector3D taillesReelles, QMatrix4x4 matGlobale, GLfloat lgCreneau, bool mur){
    //TODO
    GLfloat x = dimensions.x();
    GLfloat y = dimensions.y();
    GLfloat z = dimensions.z();

    GLint xR = taillesReelles.x();
    GLint yR = taillesReelles.y();
    GLint zR = taillesReelles.z();

    QVector3D *points = (QVector3D *)malloc(8 * sizeof(QVector3D));
    QVector3D *faces = linkgPointsPoly(points);
    QVector2D *repetitions = (QVector2D*)malloc(6 * sizeof(QVector2D));



    GLfloat decalageX = 0.0f;
    GLfloat decalageZ = 0.0f;

    int texture = 2;

    if(mur){

        //Le sol
        GLfloat longX = x/(3.0f*lgCreneau);
        GLfloat hautY = lgCreneau / 2.0f;
        GLfloat profZ = lgCreneau * 2.0f;

        GLfloat deplX = longX / 2.0f;
        GLfloat deplY = y - hautY/2.0f;
        GLfloat deplZ = profZ;


        GLfloat deplacement = -x;
        while(deplacement < x){
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau,lgCreneau/2.0f),
                                 QVector3D(deplacement + deplX,deplY, deplZ),
                                 QVector3D(0,0,0),QVector3D(1,1,1),texture);
            deplacement += longX;
        }

        //Les murs ext
        longX = x/(3.0f*lgCreneau);
        hautY = lgCreneau / 2.0f;
        profZ = lgCreneau * 2.0f;

        deplX = longX / 2.0f;
        deplY = y + hautY*2;
        deplZ = profZ * 3/2 + hautY/2.0f;

        deplacement = -x;
        while(deplacement < x){
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau,lgCreneau/2.0f),
                                 QVector3D(deplacement + deplX,deplY, deplZ),
                                 QVector3D(90,0,0),QVector3D(1,1,1),texture);
            deplacement += longX;
        }


        //Le toit ext
        createPlank(matGlobale,QVector3D(2*x,hautY,2*z),QVector3D(0,2*hautY+deplY,deplZ),QVector3D(45,0,0),QVector3D(1,1,1),texture);
        //Le toit
        createPlank(matGlobale,QVector3D(2*x,hautY,2*z + profZ),QVector3D(0,2*hautY+deplY,profZ/2),QVector3D(0,0,0),QVector3D(1,1,1),texture);
        //Le toit int
       // createPlank(matGlobale,QVector3D(2*x,hautY,2*z),QVector3D(0,2*hautY+deplY,-profZ/2),QVector3D(-45,0,0),QVector3D(1,1,1),texture);


        //Les murs int
        longX = x/(3.0f*lgCreneau);
        hautY = lgCreneau / 2.0f;
        profZ = lgCreneau * 2.0f;

        deplX = longX / 2.0f;
        deplY = y + hautY*2;
        deplZ = -profZ/2;

        deplacement = -x;
        while(deplacement < x){
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau,lgCreneau/2.0f),
                                 QVector3D(deplacement + deplX,deplY, deplZ),
                                 QVector3D(90,0,0),QVector3D(1,1,1),texture);
            deplacement += longX;
        }

        //Les murs de côtés
        longX = lgCreneau * 2.0f;
        hautY = lgCreneau / 2.0f;
        profZ = lgCreneau * 2.0f;

        deplX = longX / 4.0f;
        deplY = y + hautY*2;
        deplZ = profZ / 2.0f + z;

        createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                             QVector2D(lgCreneau,lgCreneau/2.0f),
                             QVector3D(-x+deplX,deplY, deplZ),
                             QVector3D(90,0,90),QVector3D(1,1,1),texture);
        createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                             QVector2D(lgCreneau,lgCreneau/2.0f),
                             QVector3D(x-deplX,deplY, deplZ),
                             QVector3D(90,0,90),QVector3D(1,1,1),texture);


        //Les soutiens du murs
        GLfloat xMin = -x;
        GLfloat xMax = -x + lgCreneau;
        GLfloat yMin = y - lgCreneau;
        GLfloat yMax = y;
        GLfloat zMin = z;
        GLfloat zMax = z + lgCreneau;
        points[0] = QVector3D(xMax,yMax,zMin);
        points[1] = QVector3D(xMax,yMax,zMax);
        points[2] = QVector3D(xMin,yMax,zMax);
        points[3] = QVector3D(xMin,yMax,zMin);

        points[4] = QVector3D(xMax,yMin,zMin);
        points[5] = QVector3D(xMax,yMin,zMin);
        points[6] = QVector3D(xMin,yMin,zMin);
        points[7] = QVector3D(xMin,yMin,zMin);

        faces = linkgPointsPoly(points);

        repetitions[0] = QVector2D(lgCreneau,lgCreneau);
        repetitions[1] = QVector2D(lgCreneau,lgCreneau);
        repetitions[2] = QVector2D(lgCreneau,lgCreneau);
        repetitions[3] = QVector2D(lgCreneau,lgCreneau);
        repetitions[4] = QVector2D(lgCreneau,lgCreneau);
        repetitions[5] = QVector2D(lgCreneau,lgCreneau);

        deplacement = lgCreneau/2.0f;
        while(deplacement < 2* x){
            createPolygon(6,faces,repetitions,matGlobale,QVector3D(deplacement,-lgCreneau/2,0),
                          QVector3D(0,0,0),QVector3D(1,1,1),texture);

            deplacement += longX;
        }
    }else{
        //Le sol
        GLfloat longX = x/(3.0f*lgCreneau);
        GLfloat hautY = lgCreneau / 2.0f;
        GLfloat profZ = lgCreneau * 2.0f;

        GLfloat deplX = longX / 2.0f;
        GLfloat deplY = y - hautY/2.0f;
        GLfloat deplZ = profZ/2 + z;


        GLfloat deplacement = -x;
        while(deplacement < x){
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau,lgCreneau/2.0f),
                                 QVector3D(deplacement + deplX,deplY, deplZ),
                                 QVector3D(0,0,0),QVector3D(1,1,1),texture);
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau,lgCreneau/2.0f),
                                 QVector3D(deplacement + deplX,deplY, -deplZ),
                                 QVector3D(0,0,0),QVector3D(1,1,1),texture);
            deplacement += longX;
        }
        longX = lgCreneau * 2.0f;
        hautY = lgCreneau / 2.0f;
        profZ = (z + longX)/(3.0f*lgCreneau);

        deplX = longX / 2.0f + x;
        deplY = y - hautY/2.0f;
        deplZ = profZ/2;

        deplacement = -z - longX;
        while(deplacement < z + longX){
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau/2.0f,lgCreneau),
                                 QVector3D(deplX,deplY, deplacement + deplZ),
                                 QVector3D(0,0,0),QVector3D(1,1,1),texture);
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau/2.0f,lgCreneau),
                                 QVector3D(-deplX,deplY, deplacement + deplZ),
                                 QVector3D(0,0,0),QVector3D(1,1,1),texture);
            deplacement += profZ;
        }


        //Les murs

        hautY = lgCreneau / 2.0f;
        profZ = lgCreneau * 2.0f;
        longX = (x + profZ)/(3.0f*lgCreneau);

        deplX = longX / 2.0f;
        deplY = y + hautY*2;
        deplZ = profZ + z - hautY/2.0f;

        deplacement = -x - profZ;
        while(deplacement < x + profZ){
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau,lgCreneau/2.0f),
                                 QVector3D(deplacement + deplX,deplY, deplZ),
                                 QVector3D(90,0,0),QVector3D(1,1,1),texture);
            createPerforedPlank( matGlobale, QVector3D(longX,hautY,profZ),
                                 QVector2D(lgCreneau,lgCreneau/2.0f),
                                 QVector3D(deplacement + deplX,deplY, -deplZ),
                                 QVector3D(90,0,0),QVector3D(1,1,1),texture);
            deplacement += longX;
        }

        longX = lgCreneau * 2.0f;
        hautY = lgCreneau / 2.0f;
        profZ = (z + longX)/(3.0f*lgCreneau);


        deplX = longX + x - hautY/2.0f;
        deplY = y + hautY*2;
        deplZ = profZ / 2.0f;

        deplacement = -z - longX;
        while(deplacement < z + longX){
            createPerforedPlank( matGlobale, QVector3D(profZ,hautY,longX),
                                 QVector2D(lgCreneau/2.0f,lgCreneau),
                                 QVector3D(deplX,deplY, deplacement + deplZ),
                                 QVector3D(90,0,90),QVector3D(1,1,1),texture);
            createPerforedPlank( matGlobale, QVector3D(profZ,hautY,longX),
                                 QVector2D(lgCreneau/2.0f,lgCreneau),
                                 QVector3D(-deplX,deplY, deplacement + deplZ),
                                 QVector3D(90,0,90),QVector3D(1,1,1),texture);
            deplacement += profZ;
        }


        //Le toit
        createPlank(matGlobale,QVector3D(x*2 + longX*2,lgCreneau/3,2*(z+profZ)),QVector3D(0,longX + y,0),QVector3D(0,0,0),
                    QVector3D(1,1,1),texture);


    }

}

void CastleWindow::generateEnceinteL(GLint seed,GLfloat lenght, QVector2D nbCotesEnceinte, GLint radius , attributesElementL attrMur, int typeTours, attributesElementL attrTour, QMatrix4x4 matGlobale, QVector3D translate, QVector3D rotate, QVector3D scale, int texture, int details){
    QMatrix4x4 matWorld = createMatrixWorld(translate,rotate,scale);

    int rd = randomDetails(details);
    if(attrMur.details == 0) attrMur.details = rd;
    if(attrTour.details == 0) attrTour.details = rd;

    bool premier = true;
    bool deux = true;

    QVector3D *points = (QVector3D *)malloc(8 * sizeof(QVector3D));
    QVector3D *faces = linkgPointsPoly(points);
    QVector2D *repetitions = (QVector2D*)malloc(6 * sizeof(QVector2D));

    GLfloat x, y, z;



    //On commence par calculer le nombre définitif de côté de l'enceinte
    srand (seed);
    int nbCotesEnceinteDefinitif = (rand() % (int)(nbCotesEnceinte.y() - nbCotesEnceinte.x() + 1)) + (int)nbCotesEnceinte.x();
    //qDebug()<<"Il y a "<<nbCotesEnceinteDefinitif<<" cotes"<<endl;
   // nbCotesEnceinteDefinitif = 4;
    //Va permettre de stocker la somme des angles au fur et à mesure de l'avancement de l'enceinte
    GLfloat cptAngle = 0.0f;

    //La liberte d'angle (en %) par rapport à l'angle de base
    //Pour une enceinte de 4, l'angle de base sera 90 (360/4)
    GLfloat liberteAngle = 50.0f;
    GLfloat angleDeBase = 360 / nbCotesEnceinteDefinitif;

    //Va servir pour décider si on va diminuer ou augmenter le prochain angle
    GLfloat lastAngle = 0.0f;
    //Pour continuer d'avancer
    QVector3D deplacement = QVector3D(0.0f,0.0f,radius);
    QVector3D lastMurDims = QVector3D(radius,0.0f,0.0f);
    QVector3D lastTourDims = QVector3D(0.0f,0.0f,0.0f);

    QVector3D currentMurDims;
    QVector3D currentTourDims;

    //On spawn le donjon
    QVector3D deplacementDonjon = QVector3D(0,0,- nbCotesEnceinteDefinitif/10 * radius/2.0f);
    createTourCylinder(lenght,QVector2D(10,
                                        attrTour.dimensionsY.y()),matGlobale*matWorld,deplacementDonjon+
                       QVector3D(0,attrTour.dimensionsY.y()/2,0),QVector3D(0,0,0),QVector3D(1,1,1),texture,3);

    //Deux trois tours autours
    GLfloat xTmpBat = lenght*2*sin(seed * PI/180);
    GLfloat zTmpBat = lenght*2*cos(seed * PI/180);
    createTourCylinder(lenght,QVector2D(10,
                                        attrTour.dimensionsY.y()/2),matGlobale*matWorld,deplacementDonjon +
                       QVector3D(xTmpBat,attrTour.dimensionsY.y()/4,zTmpBat),QVector3D(0,0,0),QVector3D(1,1,1),texture,3);

    xTmpBat = lenght*2*sin((seed + 135) * PI/180);
    zTmpBat = lenght*2*cos((seed + 135) * PI/180);
    createTourCylinder(lenght,QVector2D(10,
                                        attrTour.dimensionsY.y()/4),matGlobale*matWorld,deplacementDonjon +
                       QVector3D(xTmpBat,attrTour.dimensionsY.y()/4,zTmpBat),QVector3D(0,0,0),QVector3D(1,1,1),texture,3);

    while(cptAngle < 360){
        GLfloat currentAngle;

        //Pour ne pas tomber sur un angle trop bas
        if((360 - cptAngle) < (angleDeBase + (liberteAngle * angleDeBase))/100.0f){
             currentAngle = 360 - cptAngle;
        }else{
            GLfloat currentLiberteAngle = ((rand() % ((int)(liberteAngle*100 + 1)))) / 100.0f;
            currentLiberteAngle *= currentAngle;
            currentLiberteAngle /= 100.f;
            //qDebug()<<"L'angle de base : "<<angleDeBase<<" le degre de liberte : "<<liberteAngle<<" et le résultat : "<<currentLiberteAngle<<endl;
            if(lastAngle >= 0.0f){
                currentLiberteAngle = -currentLiberteAngle;
            }
            currentAngle = currentLiberteAngle + angleDeBase;
        }

        //currentAngle = 90;

        //Calcul de la taille du mur actuel
        currentMurDims.setX((rand() % (int)(attrMur.dimensionsX.y() - attrMur.dimensionsX.x() + 1)) + attrMur.dimensionsX.x());
        currentMurDims.setY((rand() % (int)(attrMur.dimensionsY.y() - attrMur.dimensionsY.x() + 1)) + attrMur.dimensionsY.x());
        currentMurDims.setZ((rand() % (int)(attrMur.dimensionsZ.y() - attrMur.dimensionsZ.x() + 1)) + attrMur.dimensionsZ.x());

        //Calcul de la taille de la tour actuelle
        currentTourDims.setX((rand() % (int)(attrTour.dimensionsX.y() - attrTour.dimensionsX.x() + 1)) + attrTour.dimensionsX.x());
        currentTourDims.setY((rand() % (int)(attrTour.dimensionsY.y() - attrTour.dimensionsY.x() + 1)) + attrTour.dimensionsY.x());
        currentTourDims.setZ((rand() % (int)(attrTour.dimensionsZ.y() - attrTour.dimensionsZ.x() + 1)) + attrTour.dimensionsZ.x());

        //Pour avoir de la continuité dans l'enceinte
        //currentTourDims.setZ(currentMurDims.z());

         //Initialisation de l'enceinte par un premier mur et une premiere tour
        if(premier){
            premier = false;

            //Création du mur
           // createMurPolygon(currentMurDims,matGlobale*matWorld,0.5f,deplacement+QVector3D(0,currentMurDims.y()/2.0f,0));


            //Création du joint
            GLfloat ajoutX = currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin((90 - currentAngle/2.0f) * PI/180);
            x = currentMurDims.x();
            //qDebug()<<currentMurDims.z()<<"  "<<currentAngle<<" "<<ajoutX<<endl;
            y = currentMurDims.y();
            z = currentMurDims.z();
            ajoutX += x/2.0f;

            points[0] = QVector3D(ajoutX, y / 2.0f, z / 2.0f);
            points[1] = QVector3D(ajoutX, y / 2.0f, z / 2.0f);
            points[2] = QVector3D(x / 2.0f, y / 2.0f, z / 2.0f);
            points[3] = QVector3D(x / 2.0f, y / 2.0f, -z / 2.0f);

            points[4] = QVector3D(ajoutX, -y / 2.0f, z / 2.0f);
            points[5] = QVector3D(ajoutX, -y / 2.0f, z / 2.0f);
            points[6] = QVector3D(x / 2.0f, -y / 2.0f, z / 2.0f);
            points[7] = QVector3D(x / 2.0f, -y / 2.0f, -z / 2.0f);

            faces = linkgPointsPoly(points);

            repetitions[0] = QVector2D(1,1);
            repetitions[1] = QVector2D((GLint)y,(GLint)x);
            repetitions[2] = QVector2D((GLint)x,(GLint)z);
            repetitions[3] = QVector2D((GLint)y,(GLint)x);
            repetitions[4] = QVector2D((GLint)x,(GLint)z);
            repetitions[5] = QVector2D((GLint)x,(GLint)z);

            //createPolygon(6,faces,repetitions,matGlobale*matWorld,deplacement+QVector3D(0,currentMurDims.y()/2.0f,0));

            //Creation de la tour
            //On se met au niveau du joint
            deplacement.setX(deplacement.x() + (ajoutX + x/2.0f)/2.0f);
            //On déplace la tour pour la coller au joint
            /**
             * On va pour ça calculer le centre du joint, puis calculer le rayon entre ce centre
             * et le centre de la tour, on calcule ensuite la position via les formules trigo
             */
            QVector3D centreJoint = deplacement;
            GLfloat lgRayon = 0;//(currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin(90 * PI/180)) / 2.0f;
            lgRayon += currentTourDims.x() / 2.0f;

            GLfloat xTmpTour = lgRayon*sin((90 + currentAngle / 2.0f) * PI/180);
            GLfloat zTmpTour = lgRayon*cos((90 + currentAngle / 2.0f) * PI/180);
            QVector3D centreTour = centreJoint + QVector3D(xTmpTour,0,zTmpTour);
            createMurPolygon(currentTourDims,matGlobale*matWorld,0.5f,centreTour+QVector3D(0,currentTourDims.y()/2.0f,0),QVector3D(0,currentAngle/2.0f + cptAngle,0),QVector3D(1,1,1),texture,attrTour.details,false);

            deplacement = centreTour;
        }else{
            if(deux){
                x = currentMurDims.x();
                y = currentMurDims.y();
                z = currentMurDims.z();

            deux = true;
            //Creation du joint
            GLfloat lgRayonJ = lastTourDims.x() /2.0f;

            GLfloat xTmpJoint = lgRayonJ*sin((cptAngle - lastAngle + (lastAngle / 2.0f + 90)) * PI/180);
            GLfloat zTmpJoint = lgRayonJ*cos((cptAngle - lastAngle + (lastAngle / 2.0f + 90)) * PI/180);
            QVector3D centreJoint = deplacement + QVector3D(xTmpJoint,0,zTmpJoint);

            GLfloat hypoJoint = sqrt(pow(currentMurDims.z(),2) + pow(currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180),2));

            GLfloat mediane = sqrt(
                        pow(hypoJoint/2.0f,2)
                      + pow(currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180),2)
                      - 2 * (hypoJoint/2.0f) * (currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180))
                      * cos((90 - lastAngle/2.0f) * PI / 180));

            GLfloat angleOppMediane = (PI/2.0f) - ((90 - lastAngle/2.0f)/2.0f)
                    + atan(
                        (
                        ((hypoJoint/2.0f) - (currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180)))
                       /((hypoJoint/2.0f) + (currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180)))
                        ) *
                        (cos(((90 - lastAngle/2.0f)/2.0f) * PI /180)
                       / sin(((90 - lastAngle/2.0f)/2.0f) * PI /180)
                         )) * 180 / PI;
            if(angleOppMediane < 0){
                angleOppMediane = -angleOppMediane;
            }
            angleOppMediane *= 2.0f;//Pas logique mais ça marche....

            GLfloat pos0145X = mediane * sin((cptAngle + angleOppMediane - (lastAngle / 2.0f)) * PI/180);
            GLfloat pos0145Z = mediane * cos((cptAngle + angleOppMediane - (lastAngle / 2.0f)) * PI/180);

            GLfloat pos26X = (hypoJoint/2.0f) * sin((cptAngle - lastAngle / 2.0f) * PI/180);
            GLfloat pos26Z = (hypoJoint/2.0f) * cos((cptAngle - lastAngle / 2.0f) * PI/180);

            GLfloat pos37X = (hypoJoint/2.0f) * sin((cptAngle - lastAngle / 2.0f + 180) * PI/180);
            GLfloat pos37Z = (hypoJoint/2.0f) * cos((cptAngle - lastAngle / 2.0f + 180) * PI/180);

            points[0] = QVector3D(pos0145X, y / 2.0f, pos0145Z);
            points[1] = QVector3D(pos0145X, y / 2.0f, pos0145Z);
            points[2] = QVector3D(pos26X, y / 2.0f, pos26Z);
            points[3] = QVector3D(pos37X, y / 2.0f, pos37Z);

            points[4] = QVector3D(pos0145X, -y / 2.0f, pos0145Z);
            points[5] = QVector3D(pos0145X, -y / 2.0f, pos0145Z);
            points[6] = QVector3D(pos26X, -y / 2.0f, pos26Z);
            points[7] = QVector3D(pos37X, -y / 2.0f, pos37Z);

            faces = linkgPointsPoly(points);

            repetitions[0] = QVector2D((currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f))),currentMurDims.z());
            repetitions[1] = QVector2D((currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f))),y);
            repetitions[2] = QVector2D((currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f))),currentMurDims.z());
            repetitions[3] = QVector2D((currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f))),y);
            repetitions[4] = QVector2D(y,(currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f))));
            repetitions[5] = QVector2D(y,(currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f))));



            createPolygon(6,faces,repetitions,matGlobale*matWorld,centreJoint+QVector3D(0,currentMurDims.y()/2.0f,0),QVector3D(0,0/*cptAngle + lastAngle*/,0));

            deplacement = centreJoint;


            //Le mur
            GLfloat lgRayonM = currentMurDims.x()/2.0f + (currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180)) /2.0f;

            GLfloat xTmpMur = lgRayonM*sin((cptAngle + 90) * PI/180);
            GLfloat zTmpMur = lgRayonM*cos((cptAngle + 90) * PI/180);
            QVector3D centreMur = deplacement + QVector3D(xTmpMur,0,zTmpMur);

            createMurPolygon(currentMurDims,matGlobale*matWorld,0.5f,centreMur+QVector3D(0,currentMurDims.y()/2.0f,0),QVector3D(0,cptAngle,0),QVector3D(1,1,1),texture,attrMur.details);

            deplacement = centreMur;

            //Le second joint
            GLfloat lgRayonSC = currentMurDims.x()/2.0f + (currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin((90 - currentAngle/2.0f) * PI/180)) /2.0f;
            GLfloat xTmpJointB = lgRayonSC*sin((cptAngle + 90) * PI/180);
            GLfloat zTmpJointB = lgRayonSC*cos((cptAngle + 90) * PI/180);
            QVector3D centreJointB = deplacement + QVector3D(xTmpJointB,0,zTmpJointB);

            hypoJoint = sqrt(pow(currentMurDims.z(),2) + pow(currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin((90 - currentAngle/2.0f) * PI/180),2));

            mediane = sqrt(pow(hypoJoint/2.0f,2) + pow(currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin((90 - currentAngle/2.0f) * PI/180),2) -
                                   2 * (hypoJoint/2.0f) * (currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin((90 - currentAngle/2.0f) * PI/180))
                           * cos((90 - currentAngle/2.0f) * PI / 180));

            angleOppMediane = (PI/2.0f) - ((90 - currentAngle/2.0f)/2.0f)
                                + atan(
                                (
                                ((hypoJoint/2.0f) - (currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin((90 - currentAngle/2.0f) * PI/180)))
                               /((hypoJoint/2.0f) + (currentMurDims.z() * sin((currentAngle/2.0f) * PI/180) / sin((90 - currentAngle/2.0f) * PI/180)))
                                    ) *
                               (cos(((90 - currentAngle/2.0f)/2.0f) * PI /180)
                              / sin(((90 - currentAngle/2.0f)/2.0f) * PI /180)
                               )) * 180 / PI;
            if(angleOppMediane < 0){
                angleOppMediane = -angleOppMediane;
            }
            angleOppMediane *= 2.0f;//Pas logique mais ça marche....


            pos0145X = (hypoJoint/2.0f) * sin(((cptAngle) + currentAngle / 2.0f) * PI/180);
            pos0145Z = (hypoJoint/2.0f) * cos(((cptAngle) + currentAngle / 2.0f) * PI/180);

            pos26X = mediane * sin((cptAngle + (currentAngle / 2.0f) - angleOppMediane) * PI/180);
            pos26Z = mediane * cos((cptAngle + (currentAngle / 2.0f) - angleOppMediane) * PI/180);

            pos37X = (hypoJoint/2.0f) * sin(((cptAngle) + currentAngle / 2.0f + 180) * PI/180);
            pos37Z = (hypoJoint/2.0f) * cos(((cptAngle) + currentAngle / 2.0f + 180) * PI/180);

            points[0] = QVector3D(pos0145X, y / 2.0f, pos0145Z);
            points[1] = QVector3D(pos0145X, y / 2.0f, pos0145Z);
            points[2] = QVector3D(pos26X, y / 2.0f, pos26Z);
            points[3] = QVector3D(pos37X, y / 2.0f, pos37Z);

            points[4] = QVector3D(pos0145X, -y / 2.0f, pos0145Z);
            points[5] = QVector3D(pos0145X, -y / 2.0f, pos0145Z);
            points[6] = QVector3D(pos26X, -y / 2.0f, pos26Z);
            points[7] = QVector3D(pos37X, -y / 2.0f, pos37Z);

            faces = linkgPointsPoly(points);

            repetitions[0] = QVector2D((GLint)x,(GLint)z);
            repetitions[1] = QVector2D((GLint)y,(GLint)x);
            repetitions[2] = QVector2D((GLint)x,(GLint)z);
            repetitions[3] = QVector2D((GLint)y,(GLint)x);
            repetitions[4] = QVector2D((GLint)x,(GLint)z);
            repetitions[5] = QVector2D((GLint)x,(GLint)z);



            createPolygon(6,faces,repetitions,matGlobale*matWorld,centreJointB+QVector3D(0,currentMurDims.y()/2.0f,0));

            deplacement = centreJointB;


            //Creation de la tour
            GLfloat lgRayonT = currentTourDims.x() / 2.0f;

            GLfloat xTmpTour = lgRayonT*sin((cptAngle + currentAngle/2.0f + 90) * PI/180);
            GLfloat zTmpTour = lgRayonT*cos((cptAngle + currentAngle/2.0f + 90) * PI/180);
            QVector3D centreTour = deplacement + QVector3D(xTmpTour,0,zTmpTour);
            createMurPolygon(currentTourDims,matGlobale*matWorld,0.5f,centreTour+QVector3D(0,currentTourDims.y()/2.0f,0),QVector3D(0,currentAngle/2.0f + cptAngle,0),QVector3D(1,1,1),texture,attrTour.details,false);

            deplacement = centreTour;
        }
        }



        //qDebug()<<currentAngle<<endl;
        lastMurDims = currentMurDims;
        lastTourDims = currentTourDims;
        lastAngle = currentAngle;
        cptAngle += currentAngle;
        //qDebug()<<cptAngle<<endl;
    }


    //LAST WALL
    /*currentMurDims.setX(20);
    createMurPolygon(currentMurDims,matGlobale*matWorld,0.5f,deplacement+QVector3D(0,currentMurDims.y()/2.0f,0),QVector3D(0,360-cptAngle,0));
    /*
    currentMurDims.setX((rand() % (int)(attrMur.dimensionsX.y() - attrMur.dimensionsX.x() + 1)) + attrMur.dimensionsX.x());
    currentMurDims.setY((rand() % (int)(attrMur.dimensionsY.y() - attrMur.dimensionsY.x() + 1)) + attrMur.dimensionsY.x());
    currentMurDims.setZ((rand() % (int)(attrMur.dimensionsZ.y() - attrMur.dimensionsZ.x() + 1)) + attrMur.dimensionsZ.x());

    GLfloat lgRayonJ = lastTourDims.x() /2.0f;

    GLfloat xTmpJoint = lgRayonJ*sin((cptAngle - lastAngle + (lastAngle / 2.0f + 90)) * PI/180);
    GLfloat zTmpJoint = lgRayonJ*cos((cptAngle - lastAngle + (lastAngle / 2.0f + 90)) * PI/180);
    QVector3D centreJoint = deplacement + QVector3D(xTmpJoint,0,zTmpJoint);

    GLfloat hypoJoint = sqrt(pow(currentMurDims.z(),2) + pow(currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180),2));

    GLfloat mediane = sqrt(
                pow(hypoJoint/2.0f,2)
              + pow(currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180),2)
              - 2 * (hypoJoint/2.0f) * (currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180))
              * cos((90 - lastAngle/2.0f) * PI / 180));

    GLfloat angleOppMediane = (PI/2.0f) - ((90 - lastAngle/2.0f)/2.0f)
            + atan(
                (
                ((hypoJoint/2.0f) - (currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180)))
               /((hypoJoint/2.0f) + (currentMurDims.z() * sin((lastAngle/2.0f) * PI/180) / sin((90 - lastAngle/2.0f) * PI/180)))
                ) *
                (cos(((90 - lastAngle/2.0f)/2.0f) * PI /180)
               / sin(((90 - lastAngle/2.0f)/2.0f) * PI /180)
                 )) * 180 / PI;
    if(angleOppMediane < 0){
        angleOppMediane = -angleOppMediane;
    }
    angleOppMediane *= 2.0f;//Pas logique mais ça marche....

    GLfloat pos0145X = mediane * sin((cptAngle + angleOppMediane - (lastAngle / 2.0f)) * PI/180);
    GLfloat pos0145Z = mediane * cos((cptAngle + angleOppMediane - (lastAngle / 2.0f)) * PI/180);

    GLfloat pos26X = (hypoJoint/2.0f) * sin((cptAngle - lastAngle / 2.0f) * PI/180);
    GLfloat pos26Z = (hypoJoint/2.0f) * cos((cptAngle - lastAngle / 2.0f) * PI/180);

    GLfloat pos37X = (hypoJoint/2.0f) * sin((cptAngle - lastAngle / 2.0f + 180) * PI/180);
    GLfloat pos37Z = (hypoJoint/2.0f) * cos((cptAngle - lastAngle / 2.0f + 180) * PI/180);

    points[0] = QVector3D(pos0145X, y / 2.0f, pos0145Z);
    points[1] = QVector3D(pos0145X, y / 2.0f, pos0145Z);
    points[2] = QVector3D(pos26X, y / 2.0f, pos26Z);
    points[3] = QVector3D(pos37X, y / 2.0f, pos37Z);

    points[4] = QVector3D(pos0145X, -y / 2.0f, pos0145Z);
    points[5] = QVector3D(pos0145X, -y / 2.0f, pos0145Z);
    points[6] = QVector3D(pos26X, -y / 2.0f, pos26Z);
    points[7] = QVector3D(pos37X, -y / 2.0f, pos37Z);

    faces = linkgPointsPoly(points);

    repetitions[0] = QVector2D((GLint)z,(GLint)x);
    repetitions[1] = QVector2D((GLint)y,(GLint)x);
    repetitions[2] = QVector2D((GLint)z,(GLint)x);
    repetitions[3] = QVector2D((GLint)y,(GLint)x);
    repetitions[4] = QVector2D((GLint)x,(GLint)z);
    repetitions[5] = QVector2D((GLint)x,(GLint)z);

    createPolygon(6,faces,repetitions,matGlobale*matWorld,centreJoint,QVector3D(0,0,0));

    deplacement = centreJoint;*/



}










