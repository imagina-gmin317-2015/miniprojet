#ifndef DEF_MAFENETRE
#define DEF_MAFENETRE

#include "castlewindow.h"

#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QSlider>

#include <QLabel>
#include <QLineEdit>

class MaFenetre : public QWidget
{
    Q_OBJECT;
    public:
    MaFenetre();
    void setCW(CastleWindow*);

    public slots:
    void changerSeed(int);
    void changerMinNbMurs(const QString & text);
    void changerMaxNbMurs(const QString & text);
    void changerRadius(const QString & text);
    void changerDetails(const QString & text);
    void changerXMinMurs(const QString & text);
    void changerXMaxMurs(const QString & text);
    void changerYMinMurs(const QString & text);
    void changerYMaxMurs(const QString & text);
    void changerZMinMurs(const QString & text);
    void changerZMaxMurs(const QString & text);
    void changerDetailsMurs(const QString & text);
    void changerXMinTours(const QString & text);
    void changerXMaxTours(const QString & text);
    void changerYMinTours(const QString & text);
    void changerYMaxTours(const QString & text);
    void changerZMinTours(const QString & text);
    void changerZMaxTours(const QString & text);
    void changerDetailsTours(const QString & text);


    private:
    CastleWindow *m_castle;

    QLabel *m_textSeed;
    QLCDNumber *m_lcdSeed;
    QSlider *m_sliderSeed;

    QLabel *m_textNbMurs;
    QLabel *m_textMinNbMurs;
    QLabel *m_textMaxNbMurs;
    QLineEdit *m_maxNbMurs;
    QLineEdit *m_minNbMurs;

    QLabel *m_textRadius;
    QLineEdit *m_radius;

    QLabel *m_textDetails;
    QLineEdit *m_details;


    QLabel *m_textMurs;
    QLabel *m_textMursX;
    QLabel *m_textMursXMin;
    QLabel *m_textMursXMax;
    QLineEdit *m_maxXMurs;
    QLineEdit *m_minXMurs;

    QLabel *m_textMursY;
    QLabel *m_textMursYMin;
    QLabel *m_textMursYMax;
    QLineEdit *m_maxYMurs;
    QLineEdit *m_minYMurs;

    QLabel *m_textMursZ;
    QLabel *m_textMursZMin;
    QLabel *m_textMursZMax;
    QLineEdit *m_maxZMurs;
    QLineEdit *m_minZMurs;

    QLabel *m_textDetailsMurs;
    QLineEdit *m_detailsMurs;


    QLabel *m_textTours;
    QLabel *m_textToursX;
    QLabel *m_textToursXMin;
    QLabel *m_textToursXMax;
    QLineEdit *m_maxXTours;
    QLineEdit *m_minXTours;

    QLabel *m_textToursY;
    QLabel *m_textToursYMin;
    QLabel *m_textToursYMax;
    QLineEdit *m_maxYTours;
    QLineEdit *m_minYTours;

    QLabel *m_textToursZ;
    QLabel *m_textToursZMin;
    QLabel *m_textToursZMax;
    QLineEdit *m_maxZTours;
    QLineEdit *m_minZTours;

    QLabel *m_textDetailsTours;
    QLineEdit *m_detailsTours;

};
#endif
